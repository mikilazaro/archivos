<?
/*$host = 'ING-BD-DES';
$usuario = 'u_des';
$clave = '123456';
$db = 'SGI_CEI';
$link = mssql_connect($host,$usuario,$clave) or die ("Error fallo al conectar con la BD _ 4");

*/
$host = "ING-BD1";
$usuario = "u_r_sgicei";
$clave = "\@232728\@";
$db = "SGI_CEI";
$link = mssql_connect($host,$usuario,$clave) or die ("Error al conectar con la BD _ 4");
?>