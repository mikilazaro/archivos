<?
/*$host = 'ING-BD-DES';
$usuario = 'u_des';
$clave = '123456';*/

$host = "ING-BD1";
$usuario = "u_rw_sgicei";
$clave = "\@232728_09\@";
$db = "SGI_CEI";
$link = mssql_connect($host,$usuario,$clave) or die ("..Error al conectar con la BD _ 3");
?>