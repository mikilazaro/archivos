<? 
session_start();
if ($_SESSION['validado'] == 'ok') {
 include('../piezas/seguridad.php');
$codi_usua_intra = $_SESSION['codiUsua'];
$usua_intra_cei = $_SESSION['nombreAlum'] . " " . $_SESSION['apaPaterAlum'] . " " . $_SESSION['apaMaterAlum'];
 ?>

               

<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
<!--<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />-->
<!--<meta name="tipo_contenido" content="text/html;" http-equiv="content-type" charset="utf-8">-->
    <title>Intranet &quot;Ingenier&iacute;a&quot;</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
    <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
    <link href="includes/intra_aca_conso_notas_asis_n.css" rel="stylesheet" type="text/css" media="screen" />
     <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>

</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">
                          <?php
            
				include("includes/conectar_academia_nuevo.php");
				$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");

				$queryAlum = "SELECT apePaterPerso, apeMaterPerso, nombrePerso from TPersona inner join TAlumno on TAlumno.codiPersona = TPersona.codiPersona where TAlumno.codiAlum = '$codi_usua_intra';";
				$resultAlum = mssql_query($queryAlum);
				$rowAlum = mssql_fetch_array($resultAlum);
				$nombreAlum = $rowAlum['apePaterPerso']." ".$rowAlum['apeMaterPerso']." ".$rowAlum['nombrePerso'];
				//echo $codi_usua_intra.' '.$nombreAlum;
				
				if (isset($_POST['ddlb_perio_lecti']))
				{
					$codiMatriAca = $_POST['ddlb_perio_lecti'];
					if (strlen($codiMatriAca) == 0)
					{
						$mostrar = 0;
					}
					else
					{
						$mostrar = 1;
					}
				}
				else
				{
					$mostrar = 1;
					$qPerioLectiAlum = "Select max(codiMatriaca) as codiMatriAca from TMatriculaAcademia where codiAlum = '$codi_usua_intra'";
					$rPerioLectiAlum = mssql_query($qPerioLectiAlum);
					$rowPerioLectiAlum = mssql_fetch_array($rPerioLectiAlum);

					$codiMatriAca = $rowPerioLectiAlum['codiMatriAca'];
				}

				/*Captura de anio, temporada, turno, ciclo, area*/
				$q1 = "select tprogramaacademia.codiAnio, tprogramaacademia.numeTempo, tprogramaacademia.codiTurno, tprogramaacademia.codiCicloAca, tprogramaacademia.codiAreaCanal from tmatriculaacademia inner join tprogramaacademia on tmatriculaacademia.codiPrograAca = tprogramaacademia.codiPrograAca where tmatriculaacademia.codiMatriAca = '$codiMatriAca';";
				$r1 = mssql_query($q1);
				$rw1 = mssql_fetch_array($r1);

				$codiAnio = $rw1['codiAnio'];
				$numeTempo = $rw1['numeTempo'];
				$codiTurno = $rw1['codiTurno'];
				$codiCicloAca = $rw1['codiCicloAca'];
				$codiAreaCanal = $rw1['codiAreaCanal'];
	
				$qFP = "select faltasJusti, faltas, permi from sia_mgaca_v_r_deta_f_fj_p where codiMatriAca = '$codiMatriAca'";
				$rFP = mssql_query($qFP);
				$rwFP = mssql_fetch_array($rFP);
				$fj = $rwFP["faltasJusti"];
				$f = $rwFP["faltas"];
				$p = $rwFP["permi"];

				$q1_1 = "select dbo.sia_mga_v_repor_encaReporAcaAsis.nombreCicloAca, dbo.sia_mga_v_repor_encaReporAcaAsis.codiCarnetAlum, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreCompleAlum, dbo.sia_mga_v_repor_encaReporAcaAsis.telePerso, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreAnio, dbo.sia_mga_v_repor_encaReporAcaAsis.numeTempo, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreTurno, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreBreveAreaC, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreSeccionAca, dbo.sia_mga_v_repor_encaReporAcaAsis.fechaHabiMatri, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreFacu, dbo.sia_mga_v_repor_encaReporAcaAsis.resuPromeEta, dbo.sia_mga_v_repor_encaReporAcaAsis.nombreBreveUni, dbo.sia_mga_v_repor_encaReporAcaAsis.puntajeMini, dbo.sia_mga_v_repor_encaReporAcaAsis.puntajeMaxi, dbo.sia_mga_v_repor_encaReporAcaAsis.puntaTotal from dbo.sia_mga_v_repor_encaReporAcaAsis where codiMatriAca = '$codiMatriAca';";

				$r1_1 = mssql_query($q1_1);
				$rw1_1 = mssql_fetch_array($r1_1);
				$nombreCicloAca = $rw1_1["nombreCicloAca"];
				$codiCarnetAlum = $rw1_1["codiCarnetAlum"];
				$nombreCompleAlum = $rw1_1["nombreCompleAlum"];
				$telePerso = $rw1_1["telePerso"];
				$nombreAnio = $rw1_1["nombreAnio"];
				$numeTempo = $rw1_1["numeTempo"];
				$nombreTurno = $rw1_1["nombreTurno"];
				$nombreBreveAreaC = $rw1_1["nombreBreveAreaC"];
				$nombreSeccionAca = $rw1_1["nombreSeccionAca"];
				$fechaHabiMatri = $rw1_1["fechaHabiMatri"];
				$nombreFacu = $rw1_1["nombreFacu"];
				$resuPromeEta = $rw1_1["resuPromeEta"];
				$nombreBreveUni = $rw1_1["nombreBreveUni"];
				$puntajeMini = $rw1_1["puntajeMini"];
				$puntajeMaxi = $rw1_1["puntajeMaxi"];
				$puntaTotal = $rw1_1["puntaTotal"];

				$q2 = "SELECT DISTINCT upper(dbo.TCursoAcademia.nombreCursoAca) as nombreCursoAca, dbo.TCursoAcademia.codiCursoAca, dbo.TDetalleProgramaCursoA.codiAnio, dbo.TDetalleProgramaCursoA.numeTempo, dbo.TDetalleProgramaCursoA.codiTurno, dbo.TDetalleProgramaCursoA.codiCicloAca, dbo.TDetalleProgramaCursoA.codiAreaCanal FROM	dbo.TDetalleProgramaCursoA INNER JOIN dbo.TCursoAcademia ON dbo.TDetalleProgramaCursoA.codiCursoAca = dbo.TCursoAcademia.codiCursoAca WHERE (dbo.TDetalleProgramaCursoA.codiAnio = '$codiAnio') AND (dbo.TDetalleProgramaCursoA.numeTempo = '$numeTempo') AND (dbo.TDetalleProgramaCursoA.codiTurno = '$codiTurno') AND (dbo.TDetalleProgramaCursoA.codiCicloAca = '$codiCicloAca') AND (dbo.TDetalleProgramaCursoA.codiAreaCanal = '$codiAreaCanal') AND (dbo.TDetalleProgramaCursoA.estaConsiEva = 1);";

				$r2 = mssql_query($q2);

				$conca = "<div id='filaNotas_in'><div id='tituCurso_in'></div><div id='eta_in'>EXAMEN TIPO ADMISION (SEMANAL)</div><div id='ft_in'>FAST TEST (DIARIO)</div><div id='tarea_in'>TAREA (Q)</div></div>";

				$conca = $conca."<div id='filaNotas_in'><div id='tituCurso_in'>Curso</div>";
				for ($i=1;$i<=3;$i++)
				{
					$conca = $conca."<div id='notaEva_in'><span class='esti1'>I".substr("0".$i,-2)."</span></div>";
				}
				//for ($i=1;$i<=15;$i++)
				for ($i=1;$i<=19;$i++)
				{
					$conca = $conca."<div id='notaEva_in'><span class='esti1'>".substr("0".$i,-2)."</span></div>";
				}
				for ($i=1;$i<=2;$i++)
				{
					$conca = $conca."<div id='notaEva_in1'><span class='esti2'>I".substr("0".$i,-2)."</span></div>";
				}
				//for ($i=1;$i<=15;$i++)
				for ($i=1;$i<=18;$i++)
				{
					$conca = $conca."<div id='notaEva_in1'><span class='esti2'>".substr("0".$i,-2)."</span></div>";
				}
				for ($i=1;$i<=5;$i++)
				{
					$conca = $conca."<div id='notaEva_in2'><span class='esti3'>".substr("0".$i,-2)."</span></div>";
				}

				$conca = $conca."</div>";

				while($rw2 = mssql_fetch_array($r2))
				{
					$canti = $canti + 1;
					$codiCursoAca = $rw2["codiCursoAca"];

					if ($canti == 1)
					{
						$conca = $conca."<div id='filaNotas_in'><div id='numeCurso_in'>".$canti."</div><div id='nombreCurso_in'>".$rw2["nombreCursoAca"]."</div>";
					}
					else
					{
						$conca = $conca."<div id='filaNotas_in'><div id='numeCurso_in'>".$canti."</div><div id='nombreCurso_in'>".$rw2["nombreCursoAca"]."</div>";
					}

					$q3 = "select codiTipoEva, nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '01' or codiTipoEva = '02' or codiTipoEva = '03' order by codiTipoEva;";
					$r3 = mssql_query($q3);
					while($rw3 = mssql_fetch_array($r3))
					{
						$codiTipoEva = $rw3["codiTipoEva"];
						$q4 = "select codiTipoSema, nombreTipoSema from TTipoSemanaAcademia where codiTipoSema = 'TS01' or codiTipoSema = 'TS02' order by codiTipoSema;";
						$r4 = mssql_query($q4);
						while($rw4 = mssql_fetch_array($r4))
						{
							$codiTipoSema = $rw4["codiTipoSema"];
							if ($codiTipoSema == 'TS01')
							{
								 if ($codiTipoEva == '01'/* or $codiTipoEva == 'TE02'*/)
								 {
								 	for ($i=1;$i<=3;$i++)
									{
										$q5 = "select notaEvaAca from TNotaEvaluacionAcademia inner join TCronogramaEvaluacionAcademia on TNotaEvaluacionAcademia.codiCronoEva = TCronogramaEvaluacionAcademia.codiCronoEvaA where TNotaEvaluacionAcademia.codiMatriAca = '$codiMatriAca' and TNotaEvaluacionAcademia.coditipoeva = '$codiTipoEva' and TNotaEvaluacionAcademia.codiCursoAca = '$codiCursoAca' and codiTipoSema = '$codiTipoSema' and numeEva = '$i';";
										$r5 = mssql_query($q5);
										$rw5 = mssql_fetch_array($r5);
										$conca = $conca."<div id='notaEva_in'>".$rw5["notaEvaAca"]."</div>";
									}
								 }
								 else
								 {
									 if (/*$codiTipoEva == 'TE01' or */$codiTipoEva == '02')
									 {
										for ($i=1;$i<=2;$i++)
										{
											$q5 = "select notaEvaAca from TNotaEvaluacionAcademia inner join TCronogramaEvaluacionAcademia on TNotaEvaluacionAcademia.codiCronoEva = TCronogramaEvaluacionAcademia.codiCronoEvaA where TNotaEvaluacionAcademia.codiMatriAca = '$codiMatriAca' and TNotaEvaluacionAcademia.coditipoeva = '$codiTipoEva' and TNotaEvaluacionAcademia.codiCursoAca = '$codiCursoAca' and codiTipoSema = '$codiTipoSema' and numeEva = '$i';";
											$r5 = mssql_query($q5);
											$rw5 = mssql_fetch_array($r5);
											$conca = $conca."<div id='notaEva_in1'>".$rw5["notaEvaAca"]."</div>";
										}
									 }
								}
							}
							else
							{
								if ($codiTipoEva == '01')
								{
									//for ($i=1;$i<=15;$i++)
									for ($i=1;$i<=19;$i++)
									{
										$q5 = "select notaEvaAca from TNotaEvaluacionAcademia inner join TCronogramaEvaluacionAcademia on TNotaEvaluacionAcademia.codiCronoEva = TCronogramaEvaluacionAcademia.codiCronoEvaA where TNotaEvaluacionAcademia.codiMatriAca = '$codiMatriAca' and TNotaEvaluacionAcademia.coditipoeva = '$codiTipoEva' and TNotaEvaluacionAcademia.codiCursoAca = '$codiCursoAca' and codiTipoSema = '$codiTipoSema' and numeEva = '$i';";
										$r5 = mssql_query($q5);
										$rw5 = mssql_fetch_array($r5);
										$conca = $conca."<div id='notaEva_in'>".$rw5["notaEvaAca"]."</div>";
									}
								}
								if ($codiTipoEva == '02')
								{
									//for ($i=1;$i<=15;$i++)
									for ($i=1;$i<=18;$i++)
									{
										$q5 = "select notaEvaAca from TNotaEvaluacionAcademia inner join TCronogramaEvaluacionAcademia on TNotaEvaluacionAcademia.codiCronoEva = TCronogramaEvaluacionAcademia.codiCronoEvaA where TNotaEvaluacionAcademia.codiMatriAca = '$codiMatriAca' and TNotaEvaluacionAcademia.coditipoeva = '$codiTipoEva' and TNotaEvaluacionAcademia.codiCursoAca = '$codiCursoAca' and codiTipoSema = '$codiTipoSema' and numeEva = '$i';";
										$r5 = mssql_query($q5);
										$rw5 = mssql_fetch_array($r5);
										$conca = $conca."<div id='notaEva_in1'>".$rw5["notaEvaAca"]."</div>";
									}
								}
								if ($codiTipoEva == '03')
								{
									for ($i=1;$i<=5;$i++)
									{
										$q5 = "select notaEvaAca from TNotaEvaluacionAcademia inner join TCronogramaEvaluacionAcademia on TNotaEvaluacionAcademia.codiCronoEva = TCronogramaEvaluacionAcademia.codiCronoEvaA where TNotaEvaluacionAcademia.codiMatriAca = '$codiMatriAca' and TNotaEvaluacionAcademia.coditipoeva = '$codiTipoEva' and TNotaEvaluacionAcademia.codiCursoAca = '$codiCursoAca' and codiTipoSema = '$codiTipoSema' and numeEva = '$i';";
										$r5 = mssql_query($q5);
										$rw5 = mssql_fetch_array($r5);
										$conca = $conca."<div id='notaEva_in2'>".$rw5["notaEvaAca"]."</div>";
									}
								}
							}
						}
					}
					$conca = $conca."</div>";
				}

				$codiTipoEva = '01';
				$promedioETA = array();

				$conca1 = $conca1."<div id='filaNotas_in'><div id='descrip_in'><span class='esti1'>DESCRIPCION</span></div>";
				
				for ($i=1;$i<=3;$i++)
				{
					$conca1 = $conca1."<div id='capa_in'><span class='esti1'>I".substr("0".$i,-2)."</span></div>";
				}
				//for ($i=1;$i<=15;$i++)
				for ($i=1;$i<=18;$i++)
				{
					$conca1 = $conca1."<div id='capa_in'><span class='esti1'>".substr("0".$i,-2)."</span></div>";
				}
				$conca1 = $conca1."</div>";

				for ($i=1;$i<=3;$i++)
				{
					if ($i==1)
					{
						$conca1 = $conca1."<div id='filaNotas_in'><div id='descrip_in'>Fecha de evaluacion: </div>";
					}
					else
					{
						if ($i==2)
						{
							$conca1 = $conca1."<div id='filaNotas_in'><div id='descrip_in'>Orden Merito Area: </div>";
						}
						else
						{
							if ($i==3)
							{
								$conca1 = $conca1."<div id='filaNotas_in'><div id='descrip_in'>Nota: </div>";
							}
						}
					}
					//for ($j=1;$j<=18;$j++)
					for ($j=1;$j<=21;$j++)
					{
						if ($j<=3)
						{
							$codiTipoSema = 'TS01';
							$k = $j;
						}
						else
						{
							$codiTipoSema = 'TS02';
							$k = $j - 3;
						}
						if ($i==1)
						{
							$q6 = "select convert(char(10),fechaEva,103) as fecha from TCronogramaEvaluacionAcademia where codiAnio = '$codiAnio' and numeTempo = '$numeTempo' and codiTurno = '$codiTurno' and codiCicloAca = '$codiCicloAca' and codiTipoEva = '$codiTipoEva' and codiTipoSema = '$codiTipoSema' and numeEva = '$k';";
							$r6 = mssql_query($q6);
							$rw6 = mssql_fetch_array($r6);
							$conca1 = $conca1."<div id='capa_in'>".substr($rw6["fecha"],0,5)."</div>";
						}
						else
						{
							if ($i==2)
							{
								$q7 = "select ordenMeriArea from TConsolidadoNotaEvaluacionA inner join TCronogramaEvaluacionAcademia on TConsolidadoNotaEvaluacionA.codiCronoEvaA = TCronogramaEvaluacionAcademia.codiCronoEvaA where codiMatriAca = '$codiMatriAca' and TCronogramaEvaluacionAcademia.codiTipoEva = '$codiTipoEva' and TCronogramaEvaluacionAcademia.codiTipoSema = '$codiTipoSema' and TCronogramaEvaluacionAcademia.numeEva = '$k';";
								$r7 = mssql_query($q7);
								$rw7 = mssql_fetch_array($r7);

								$q8 = "select count(TMatriculaAcademia.codiMatriAca) as total from TMatriculaAcademia left outer join TMovimientoMatriculaAcademia on TMatriculaAcademia.codiMatriAca = TMovimientoMatriculaAcademia.codiMatriAca inner join TProgramaAcademia on TMatriculaAcademia.codiPrograAca = TProgramaAcademia.codiPrograAca where codiAnio = '$codiAnio' and numeTempo = '$numeTempo' and TProgramaAcademia.codiCicloAca = '$codiCicloAca' and codiAreaCanal = '$codiAreaCanal' and estaRatiMatri = 1 and codiMotiMovi is null;";
								$r8 = mssql_query($q8);
								$rw8 = mssql_fetch_array($r8);
								//echo $rw8["total"] . " - ";
								if (($rw8["total"] <> 0) and ($rw7["ordenMeriArea"] <> 0))
								{
									$var = $rw7["ordenMeriArea"]."/".$rw8["total"];
								}
								else
								{
									$var = '';
								}
								$conca1 = $conca1."<div id='capa_in'>".$var."</div>";
							}
							else
							{
								if ($i==3)
								{
									$q9 = "select codiCronoEvaA from TCronogramaEvaluacionAcademia where codiAnio = '$codiAnio' and numeTempo = '$numeTempo' and codiTurno = '$codiTurno' and codiCicloAca = '$codiCicloAca' and codiTipoEva = '$codiTipoEva' and codiTipoSema = '$codiTipoSema' and numeEva = '$k';";
									$r9 = mssql_query($q9);
									$rw9 = mssql_fetch_array($r9);
									$codiCronoEvaA = $rw9["codiCronoEvaA"];

									$q10 = "select puntaTotal, puntatotalVige from TConsolidadoNotaEvaluacionA where codiCronoEvaA = '$codiCronoEvaA' and codiMatriAca = '$codiMatriAca';";
									$r10 = mssql_query($q10);
									$rw10 = mssql_fetch_array($r10);
									
									//$conca1 = $conca1."<div id='capa_in'>".round($rw10["puntaTotal"],2)."/".round($rw10["puntatotalVige"],1)."</div>";
									$conca1 = $conca1."<div id='capa_in1'>".round($rw10["puntatotalVige"],2)."</div>";
									if (round($rw10["puntatotalVige"],2) > 0)
									{
										$promedioETA[] = round($rw10["puntatotalVige"],2);
									}

									/*set @detaPuntaNota = cast(convert(decimal(6,2),round(@puntaTotalObte,2,0)) as varchar(8)) + '/' + cast(convert(decimal(6,1),round(@notaObte,1,0)) as varchar(8))*/
								}
							}
						}
						
					}
					$conca1 = $conca1."</div>";
				}
				$var = implode(" ", $promedioETA);
				//print_r($promedioETA);

			?>
                        <?php
								echo "REPORTE ACADÉMICO Y DE ASISTENCIA (".utf8_encode(strtoupper($nombreCicloAca)).") - ".utf8_encode(strtoupper($nombreTurno));
							?></span></h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix">
                      <form action="" method="post" name="formu_opcio">
                <?php
						$consultaQuery = "SELECT dbo.TMatriculaAcademia.codiMatriAca, dbo.TCicloPreparacionAcademia.nombreCicloAca + '     ' + dbo.TAnio.nombreAnio + '-' + CAST(dbo.TProgramaAcademia.numeTempo AS varchar) + '      ' + UPPER(dbo.TTurno.nombreTurno) AS ciclo FROM         dbo.TMatriculaAcademia INNER JOIN dbo.TProgramaAcademia ON dbo.TMatriculaAcademia.codiPrograAca = dbo.TProgramaAcademia.codiPrograAca INNER JOIN dbo.TCicloPreparacionAcademia ON dbo.TProgramaAcademia.codiCicloAca = dbo.TCicloPreparacionAcademia.codiCicloAca INNER JOIN                    dbo.TAnio ON dbo.TProgramaAcademia.codiAnio = dbo.TAnio.codiAnio INNER JOIN dbo.TTurno ON dbo.TProgramaAcademia.codiTurno = dbo.TTurno.codiTurno WHERE (dbo.TMatriculaAcademia.codiAlum = '$codi_usua_intra') ORDER BY dbo.TMatriculaAcademia.fechaMatri DESC;";


					$consulta = mssql_query($consultaQuery);
				

				?>
                <strong> Selecciona ciclo académico :</strong>
<select name="ddlb_perio_lecti" id="ddlb_perio_lecti" onChange="this.form.submit()">
            <option value='0'>-- Seleccione --</option>
                                       <?php while($registro=mssql_fetch_array($consulta))
					{	
						?>
                                       <OPTION value="<?php echo $registro['codiMatriAca'];?>" <?php if ( $registro['codiMatriAca'] == $codiMatriAca  ) { echo 'selected';}?>   ><?php echo utf8_encode($registro['ciclo']);?></OPTION>
                                       <?php 
						}
						?>
                                     </select>
                
               <!-- <input name="cb_mostrar" type="submit" class="art-button" onClick="validar($codiGrado)" value="Mostrar" />-->
                </form>
                     
                      <div id="conte_total_in" style=" overflow-y:scroll; overflow-x:scroll; height:440px; width:100%">
                	<div id="conte_enca_in">
                    	<div id="titu_conte_enca_in">
                        	
							<?php
								echo "REPORTE ACADÉMICO Y DE ASISTENCIA (".utf8_encode(strtoupper($nombreCicloAca)).") - ".utf8_encode(strtoupper($nombreTurno));
							?>
                            
                        </div>
                        <div id="cuerpo_conte_enca_in">
                        	<div id = "conte_deta_datos_enca_in">
                            	<div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	C&oacute;digo:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $codiCarnetAlum;
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti2_in">
                                    	<span class="eti1">
                                        	Apellidos y nombre(s):
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="obje2_in">
                                    	<span class="obje1">
                                        	<?php
												echo utf8_encode($nombreCompleAlum);
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Tel&eacute;fono:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $telePerso;
											?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div id = "conte_deta_datos_enca_in">
                            	<div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Temporada:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $nombreAnio.'-'.$numeTempo;
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Turno:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo utf8_encode($nombreTurno);
											?>
                                        </span>
                                    </div>
                                    <div id="eti1_in">
                                    	<span class="eti1">
                                        	Área:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $nombreBreveAreaC;
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Secci&oacute;n:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $nombreSeccionAca;
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Matr&iacute;cula:
                                        </span>
                                    </div>
                                    <div id="obje1_in">
                                    	<span class="obje1">
                                        	<?php
												echo $codiMatriAca;
											?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div id = "conte_deta_datos_enca_in">
                            	<div id="fila_datos_in">
                                	<div id="eti1_in">
                                    	<span class="eti1">
                                        	Facultad:
                                        </span>
                                    </div>
                                    <div id="obje3_in">
                                    	<span class="obje1">
                                        	<?php
												echo utf8_encode($nombreFacu); /*$resuPromeEta, $nombreBreveUni, $puntajeMini, $puntajeMaxi, $puntaTotal*/
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti3_in">
                                    	<span class="eti1">
                                        	Promedio ETAS:
                                        </span>
                                    </div>
                                    <div id="obje3_in">
                                    	<span class="obje1">
                                        	<?php
												echo $resuPromeEta; /*$resuPromeEta, $nombreBreveUni, $puntajeMini, $puntajeMaxi, $puntaTotal*/
											?>
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	<div id="eti3_in">
                                    	<span class="eti1">
                                        	Ptje examen admisi&oacute;n:
                                        </span>
                                    </div>
                                </div>
                                <div id="fila_datos_in">
                                	
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="conte_falta_in">
	                    <div id="fila_falta_in0">
                        	Record de Inasistencia:
                        </div>
                    	<div id="fila_falta_in">
                        	<div id="titu_fila_falta_in">
                            	Justificadas: 
                            </div>
                            <div id="cuerpo_fila_falta_in">
                            	<?php
									echo $fj;
								?>
                            </div>
                        </div>
                        <div id="fila_falta_in">
                            <div id="titu_fila_falta_in">
                            	No justificadas: 
                            </div>
                            <div id="cuerpo_fila_falta_in">
	                            <?php
									echo $f;
								?>
                            </div>
                        </div>
                        <div id="fila_falta_in">
                        	<div id="titu_fila_falta_in">
                            	Permisos: 
                            </div>
                            <div id="cuerpo_fila_falta_in">
                            	<?php
									echo $p;
								?>
                            </div>
                        </div>
                    </div>
                    <div id="conte_notas_in">
						<?php
                            echo utf8_encode($conca);
                        ?>
                    </div>
                    <div id="conte_resu_notas_in">
						<?php
                            echo utf8_encode($conca1);
                        ?>
                    </div>
                    <div id="grafico">
                    	<?php
							echo "<img src = \"grafico-barra1.php?codi=$var\" style='text-align:center' />";
						?>
                    </div>
                </div>
			       
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<? 
}
else
{ header('location: ../index.php');
  echo "No ha validado su sessión";
}
?>