<?php if (utf8_encode($_SESSION["tipoAlumno"]) == "Estudiante de Académia"){ ?>
<nav class="art-nav">
    <ul class="art-hmenu"><!--<li><a href="new-page.html" class="">Inicio</a><ul class=""><li><a href="new-page/new-page.html" class="">Subpágina 1</a></li></ul></li>--><li><a href="../academia/intra_aca_conso_notas_asis_n.php"><img src="../estilos/images/actividades_intranet.png" alt="" width="30" height="30"  /> Consolidado de notas y asistencia</a></li>
      <li><a href="../academia/intra_aca_hora.php"><img src="../estilos/images/agenda_intranet.png" alt="" width="30" height="30"  /> Horario</a></li>
      
      <li><a href="#"><img src="../estilos/images/icono-calendario.png" alt="" width="30" height="30"  />Cronograma</a>
        <ul>
          <li><a href="../academia/intra_aca_rol_sema.php">✔ Semanal</a></li>
          <li><a href="../academia/intra_aca_rol_eva.php">✔ Evaluaciones</a></li>
        </ul>
      </li>
      <li><!--<a href="../academia/intra_aca_cambio_contra_n.php"><img src="../estilos/images/candado.png" alt="" width="30" height="30"  />Cambiar contraseña</a>-->
      <a title="Cambiar clave" href="#cambiarclave" data-toggle="modal"><img src="../estilos/images/candado.png" alt="" width="30" height="30"  />Cambiar contraseña</a>
      
      </li>
      <li><a href="../piezas/cerrar-sesion.php"><img src="../estilos/images/salir.png" alt="" width="30" height="30"  />Salir</a></li>
     </li>
  </ul>
</nav>
<?php  }elseif ( utf8_encode($_SESSION["tipoAlumno"]) == "Secundaria"){ 

?>
 
<nav class="art-nav">
    <ul class="art-hmenu"><!--<li><a href="new-page.html" class="">Inicio</a><ul class=""><li><a href="new-page/new-page.html" class="">Subpágina 1</a></li></ul></li>-->
    <li><a href="../intranet/intra_ini.php"><img src="../estilos/images/inicio.png" alt="" width="30" height="29"  /> Inicio</a></li>
      <li><a href="#"><img src="../estilos/images/icono-calendario.png" alt="" width="30" height="30"  /> Calendarización</a>
        <ul>
          <li><a href="../intranet/intra_calen_progra_perio_eva.php">✔ Programa anual</a></li>
        </ul>
      </li>
      <li><a href="#"><img src="../estilos/images/academico.png" alt="" width="30" height="30"  />Académico</a>
        <ul>
          <li><a href="../intranet/intra_repor_aca_asis.php">✔ Notas y asistencia</a></li>
          <li><a href="../intranet/intra_bole_notas_bimes.php">✔ Boleta de notas</a></li>
          <li><a href="../intranet/notas_nive.php">✔ Notas de nivelación</a></li>
        </ul>
      </li>
      <li><a href="../piezas/cerrar-sesion.php"><img src="../estilos/images/salir.png" alt="" width="30" height="30"  />Salir</a></li>
  </ul>
</nav>
<?php  }elseif ( utf8_encode($_SESSION["tipoAlumno"]) == "Marketing"){ 
echo $_SESSION["tipoAlumno"];
?>
 
<nav class="art-nav">
    <ul class="art-hmenu">
    <li><a href="../fotos/lista-alumnossinfoto.php"><img src="../estilos/images/actividades_intranet.png" alt="" width="30" height="27"  />Lista de estudiantes</a></li>
    <li><a href="../fotos/lista-alumnos.php"><img src="../estilos/images/estudiantes.png" alt="" width="30" height="30"  />Lista de estudiantes (Foto)</a></li>
      <li><a href="../piezas/cerrar-sesion.php"><img src="../estilos/images/salir.png" alt="" width="30" height="30"  />Salir</a></li>
  </ul>
</nav>
<?php  }?>