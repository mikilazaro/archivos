<?php  $favicon = 'fav.png';  
	$urlraiz = $_SERVER['DOCUMENT_ROOT']."/intranet/";
    ?>
