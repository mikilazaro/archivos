<style>.art-content .art-postcontent-0 .layout-item-0 { margin-bottom: 10px;  }
.art-content .art-postcontent-0 .layout-item-1 { border-spacing: 10px 0px; border-collapse: separate;  }
.art-content .art-postcontent-0 .layout-item-2 { border-top-style:solid;border-right-style:solid;border-bottom-style:solid;border-left-style:solid;border-top-width:1px;border-right-width:1px;border-bottom-width:1px;border-left-width:1px;border-top-color:#D9D0C9;border-right-color:#D9D0C9;border-bottom-color:#D9D0C9;border-left-color:#D9D0C9; padding-right: 10px;padding-left: 10px; border-radius: 15px;  }
.ie7 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell {border:none !important; padding:0 !important; }
:required:focus {
  box-shadow: 0  0 3px rgba(255,0,0,0.5); 
}
</style>
<header class="art-header">

    <div class="art-shapes">
        
            </div>

<h2 class="art-slogan">Inscríbete aquí</h2>



<a href="#" class="art-logo art-logo-1088832390">
    <img src="estilos/images/logo-1088832390.png" alt="">
</a>

<nav class="art-nav">
    <div class="art-nav-inner">
    <ul class="art-hmenu">
      <li><a href="index.php" class="active">Pre Inscríbete aquí</a></li>
      <li><a target="_blank" href="http://www.ingenieria.edu.pe/">Complejo</a></li>
      <li><a  target="_blank" href="http://www.academiaingenieria.edu.pe/">Academia</a></li><li><a target="_blank"  href="http://www.iepingenieria.edu.pe/">Colegio</a></li><li><a  target="_blank"  href="http://www.preacademiaingenieria.edu.pe/">Pre Académia</a></li>
       </ul> 
        </div>
  </nav>

                    
</header>