<?php
if (isset($_POST['cb_enviar'])) {
$email = $_POST['sle_email'];
$descrip = $_POST['mle_descrip'];

if ($email == '')
{
if (!isset($_SESSION)) {
  session_start();
  session_unset();
session_destroy();
} 

 $mensaEnvio = "Ingrese su correo electrónico"; }
elseif ($descrip == '') { $mensaEnvio = "No ha Ingresado el comentario/sugerencia"; }
else
{

include($urlraiz.'/academia/includes/conectar_academia_nuevo.inc');
$db_link = mssql_select_db($db,$link) or die ("El Nombre de la base de datos no es correcto");
$sql = "Select max(numSuge) from TSugerenciaSWD;";
$result = mssql_query($sql);
$contePagiIniIntra = mssql_fetch_row($result);
$maxNumeSuge = intval(substr($contePagiIniIntra[0],2,4))+1;
$cadeCodi = '0000' . strval($maxNumeSuge);
$numeDigi = strlen($cadeCodi);
$nuevoCodiSuge = 'S' . substr($cadeCodi,$numeDigi-4,4);

 
$sql = "Insert into TSugerenciaSWD(numSuge,codiAlum,email,descripSuge) values ('" . $nuevoCodiSuge . "','" . $codi_usua_intra . "','" . $email . "','" . $descrip . "');";
$result = mssql_query($sql);
if ($result) {

	   $seEnvio;      //Para determinar si se envio o no el correo
//     $destinatario = 'mlazaro@ingenieria.edu.pe';        
     $destinatario = 'mikipl@hotmail.com';        
     $elmensaje = str_replace("\n.", "\n..",  $descrip);     
     $elmensaje = wordwrap($elmensaje, 70);                      
     $asunto = 'Mensaje desde INTRANET';

     $cuerpomsg ='
<html>
<head>
  <title>Mensaje Recibido!!</title>
</head>
<body>
<p>Mensaje enviado desde INTRANET (Sugerencias o Comentarios)</p>
  <table>
    <tr>
      <td><b>Correo: </b>'. $email.' <br></td>
    </tr>
    <tr>
      <td><b>Mensaje:</b><br></td>
    </tr>
    <tr>
      <td>'.$elmensaje.'</td>
    </tr>
   
  </table>
</body>
</html>
 ';
//Establecer cabeceras para la funcion mail()
    //version MIME
    $cabeceras = "MIME-Version: 1.0\r\n";
    //Tipo de info
    $cabeceras .= "Content-type: text/html; charset=iso-8859-1\r\n";
    //direccion del remitente
    $cabeceras .= "From: ".utf8_encode($_SESSION["nombreAlum"])." <".$email.">";
   
    if(mail($destinatario,$asunto,$cuerpomsg,$cabeceras))
        $seEnvio = true;
    else
        $seEnvio = false;
	//Hasta aqui el envio de mensajes
}
$mensaEnvio = "✔ Se envió el mensaje en forma satisfactoria, muchas gracias". $mensajeenviocorreo;

}
}
 ?>
 <?php
if(isset($_POST['btnSubirfoto'])){
//comprobamos si ha ocurrido un error.
if ($_FILES["imagen"]["error"] > 0){
$mesajefoto = "<hr>! Seleccione una foto";
} else {
	$permitidos = array("image/jpg", "image/jpeg", "image/gif", "image/png");
	$limite_kb = 1000;

	if (in_array($_FILES['imagen']['type'], $permitidos) && $_FILES['imagen']['size'] <= $limite_kb * 1024){
			$ruta_imagen = $_FILES["imagen"]["tmp_name"];
$miniatura_ancho_maximo = 200;
$miniatura_alto_maximo = 250;

$info_imagen = getimagesize($ruta_imagen);
$imagen_ancho = $info_imagen[0];
$imagen_alto = $info_imagen[1];
$imagen_tipo = $info_imagen['mime'];

switch ( $imagen_tipo ){
	case "image/jpg":
	case "image/jpeg":
		$imagen = imagecreatefromjpeg( $ruta_imagen );
		break;
	case "image/png":
		$imagen = imagecreatefrompng( $ruta_imagen );
		break;
	case "image/gif":
		$imagen = imagecreatefromgif( $ruta_imagen );
		break;
}

$lienzo = imagecreatetruecolor( $miniatura_ancho_maximo, $miniatura_alto_maximo );

imagecopyresampled($lienzo, $imagen, 0, 0, 0, 0, $miniatura_ancho_maximo, $miniatura_alto_maximo, $imagen_ancho, $imagen_alto);

$calidad=95;

$resultado =  imagejpeg($lienzo,$urlraiz."fotos/fotos_academia/".$_SESSION["User"].'.jpg' ,$calidad);

			if ($resultado){
	$mesajefoto = "<hr>✔ Se subió tu foto";
			} else {
				$mesajefoto = "<hr>! Seleccione una foto";
			}
		
	} else {
		echo "archivo no permitido, es tipo de archivo prohibido o excede el tamano de $limite_kb Kilobytes";
	}
}}
	

	
?>
<div class="art-layout-cell art-sidebar1"><div class="art-block clearfix">
        <div class="art-blockheader">
            <h3 class="t">Bienvenido!</h3>
        </div>
        <div class="art-blockcontent"><strong><em><?php echo utf8_encode($_SESSION["tipoAlumno"]) ?></em>
        <?php if(isset($_SESSION["detalletipo"])){echo '<br />'.utf8_encode($_SESSION["detalletipo"]);}?>
        </strong>
          <p><span style="color: rgb(75, 63, 53);"><img src="<?php if (file_exists("../fotos/fotos_academia/".$_SESSION["User"].'.jpg') and $_SESSION["User"] != ''){ echo "../fotos/fotos_academia/".$_SESSION["User"].'.jpg';}else{echo '../fotos/fotos_academia/defecto.jpg';} ?>" width="78" height="100"class="art-lightbox" style="float: left;"></span></p><!--<p><span >5 GRADO - AUDACIA</span></p>--><p><span ><strong>Nombre</strong>:<br />
 <?php echo utf8_encode($_SESSION["nombreAlum"]);?></span></p><p><span ><strong>Apellidos:</strong><br />
 <?php echo utf8_encode($_SESSION["apellidoAlum"]);?></span></p><p><span ><strong>Codigo:</strong> <br />
<?php echo strtoupper($_SESSION["User"]); ?></span>

        </p>
      
        <form name="form1" id="form1" method="post" action="" enctype="multipart/form-data">

				<label class="subirimg"><strong>Cambiar foto:</strong></label>
				<input name="imagen" id="imagen" type="file" style="width:100%" />
			
			 <em>  <strong><?php echo $mesajefoto; ?></strong></em>

							<input name="btnSubirfoto" id="btnSubirfoto" class="art-button" type="submit" value="Subir Foto" />
          <a href="../piezas/cerrar-sesion.php" class="art-button">Salir <--</a>		
	</form>
    

        </div>
</div>
<div class="art-block clearfix">
        <div class="art-blockheader">
            <h3 class="t">Sugerencias/Comentarios</h3>
        </div>
        <div class="art-blockcontent">
         
          <form action="" method="post" name="formu_suge">
					<input style="width:100%" required="required" name="sle_email" id="sle_email" type="email"  placeholder="e-mail..." /><br>
<br>

				  <textarea style="width:100%" required="required" name="mle_descrip"  rows="8" placeholder="Descripción..." ></textarea>
				<br>

					  <input name="cb_enviar" id="cb_enviar" type="submit" value="Enviar"   class="art-button"/> <? echo $mensaEnvio; ?>
				  </form>
         </div>
</div></div>