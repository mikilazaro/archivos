<footer class="art-footer" style=" background-image:url(../estilos/images/fondoabajo.png) ;background-repeat: no-repeat; background-position:right">
  <div class="art-footer-inner">
<div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-0" style="width: 33%">
        <p style="text-align: center;">Academia Ingeniería: Calle Real 231 El Tambo - Hyo Teléfonos: 247607 - 254096 
        e-mail: academia@ingenieria.edu.pe<br></p>
    </div><div class="art-layout-cell layout-item-0" style="width: 34%">
        <p>Colegio Ingeniería: Calle Real 233 El Tambo - Hyo Teléfonos: 247607 - 254096 
        e-mail: colegio@ingenieria.edu.pe
        <br></p>
    </div><div class="art-layout-cell layout-item-0" style="width: 33%">
        <p>Pre Academia Ingeniería: Calle Real 233 El Tambo - Hyo Teléfonos: 247607 - 254096 
        e-mail: preacademia@ingenieria.edu.pe<br></p>
    </div>
    </div>
</div>

   <!-- <p class="art-page-footer">
        <span id="art-footnote-links"><a href="" target="_blank">Diseño</a> Creado por Miki Lázaro.</span>
    </p>-->
  </div>
</footer>
<!--Imagen para fondo abajo-->
<!--<img src="../estilos/images/fondoabajo.png" title="Ir arriba" style="position: fixed; bottom: 0px; right: -10%;" />-->