<?php include('piezas/seguridad.php'); ?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Buscar Ficha</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="estilos/style.css" media="screen">
    <link rel="stylesheet" href="estilos/style.responsive.css" media="all">
    <link rel="icon" href="estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="estilos/jquery.js"></script>
    <script src="estilos/script.js"></script>
    <script src="estilos/script.responsive.js"></script>
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php //include('piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">¿Ya te inscribiste antes?</span>  <em>Busca tu ficha de Pre Inscripción</em></h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix">
                                   
                      <form action="" method="get" name="frmbuscar" id="frmbuscar" style="text-align:right">
                                    <em>Ingrese DNI del estudiante Pre Inscrito :</em>
                        <input class="art-search" size="60" name="buscar" type="search"  autofocus id="buscar" placeholder="Buscar por DNI" value="<?php if (isset($_GET['buscar'])) {echo $_GET['buscar']; }?>">
                   </form>
                   <?php if(isset($_GET['buscar']) and strlen($_GET['buscar'])==8){ ?>
                
               <!--    <div class="layout-item-2" style="width: 100%; background-color:#FFE6E6; padding:2px; color: #903;;text-align: center; font-size:10px" >
       
       <div  style="text-align:center"><strong>Nota: </strong></div>
        * IMPRIME la ficha y entrega al momento de tu matrícula en nuestra oficina de informes.
   <br>
     </div>
    </div>
-->
                   
<div ><iframe src="includes/reporte_pre_inscrip.php?buscar=<?php echo $_GET['buscar'];?>" width=100% height=492px frameborder=0></iframe></div>                   <?php }else{ ?>
<br>
<br>
<em>* Ingrese el formato de DNI correcto y presione ENTER para buscar</em>
<br>
<br>

<?php }?>
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>