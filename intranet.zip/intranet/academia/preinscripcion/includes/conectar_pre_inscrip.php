<?php
$myServer = "ING-BD1";
$myUser = "u_rw_sgicei";
$myPass = "\@232728_09\@";
$db = "SGI_CEI";

/*$myServer = 'ING-BD-DES';
$myUser = 'u_des';
$myPass = '123456';
$db = 'SGI_CEI';*/
//connection to the database
$link = mssql_connect($myServer, $myUser, $myPass)
  or die("No se puede conectar a SQL Server en $myServer. Error: " . mssql_get_last_message());

//select a database to work with
$selected = mssql_select_db($db, $link)
  or die("Couldn't open database $db");
