<?php 
   class consul_bd_aca{
   var $link;
   var $result; 
   var $nuevoCodi;
      function conectar(){

	     if (!($this->link=mssql_connect('ING-BD1','u_rw_sgicei','\@232728_09\@'))){
//if (!($this->link=mssql_connect('ING-BD-DES','u_des','123456'))){
            echo "Error al conectarse con la base de datos.";
            exit();
         }
         if (!mssql_select_db('SGI_CEI',$this->link)){
            echo "Error al seleccionar la base de datos.";
            exit();
         }
         //return $this->link;
      }
      function consulta($sql){
         $this->result=mssql_query($sql, $this->link);
         return $this->result;
      }
      function mostrarCampos($result){
         $this->result=mssql_fetch_array($result);
         return $this->result;
      }
	  function mostrarRegistros($result){
         $this->result=mssql_fetch_row($result);
         return $this->result;
      }
	  function hallarNuevoCodi($result){
	  	
		if($regisConsul = $this->mostrarCampos($result))
		     { $ultiCodi = $regisConsul['maxiCodi']; }
		else { echo "Error al realizar la consulta"; }
		if ($ultiCodi == '')
		{
			$nuevoCodi = 'PI000001';
		}
		else
		{
			$nuevoCodi = '000000' . strval(intval(substr($ultiCodi,2,6)) + 1);
			$longiNuevoCodi = strlen($nuevoCodi);
			$nuevoCodi = 'PI' . substr($nuevoCodi,$longiNuevoCodi-6,6);
		}
		$this->nuevoCodi = $nuevoCodi;
		return $this->nuevoCodi;
	  }
      function desconectar(){
         mssql_close();
      }
   }
   
 ?>