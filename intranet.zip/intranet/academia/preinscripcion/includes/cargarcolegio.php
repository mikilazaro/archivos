<?php
	include("conectar_pre_inscrip.php");
 if(isset($_POST['q']) and $_POST['q'] !=''){
$q=$_POST['q'];

		$qCole = "SELECT codiCole, upper(nombreCole), upper(centroPoblaCole)
 FROM TColegio where (codiNivelModa = 'F0' or codiNivelModa = 'G0') and  TColegio.codiProvinCole = '".$q."'
order by nombreCole,centroPoblaCole";
											$rCole = mssql_query($qCole);

											echo "<select name='colePromoAlum' onchange='verotrocole(this.value)'  required id='colePromoAlum' style='width:270px; font-size:11px;'>";
											echo "<option value=''>Elige</option>";
											echo "<option value='IE0000000_'>OTRO COLEGIO</option>";
											while($reg=mssql_fetch_row($rCole))
											{
												echo "<option value='".$reg[0]."'>".utf8_encode($reg[1])."   -     [ ".utf8_encode($reg[2])." ]"."</option>";
											}
											echo "</select>";}
 elseif(isset($_POST['prov'])){		
 $q=$_POST['prov'];
		$qCole = "SELECT codiProvin, nombreProvin FROM TProvincia WHERE codiDepar= '".$q."'";
											$rCole = mssql_query($qCole);

											echo "<select name='coledepa' required id='coledepa' onchange='load(this.value)' style='width:270px; font-size:11px;'>";
											echo "<option value=''>Elige</option>";
											while($reg=mssql_fetch_row($rCole))
											{
												echo "<option value='".$reg[0]."'>".utf8_encode($reg[1])."</option>";
											}
											echo "</select>";
 }
?>
