function load(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
}
}
xmlhttp.open("POST","includes/cargarcolegio.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("q="+str);
}

function cargarprovincia(str)
{
var xmlhttp;
 
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("divprovincia").innerHTML=xmlhttp.responseText;
}
}
xmlhttp.open("POST","includes/cargarcolegio.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("prov="+str);
}
function verotrocole(str)
{
	
	var id = str;
	var div = document.getElementById('divotrocole');
	if (id == "IE0000000_")
	{
		
		div.style.display = 'block';	
		document.frm_Pre_Inscrip.otrocole.value='';
		document.frm_Pre_Inscrip.otrocole.disabled = false;
	}else{
	document.frm_Pre_Inscrip.otrocole.disabled = true;
	div.style.display = 'none';
	}
}