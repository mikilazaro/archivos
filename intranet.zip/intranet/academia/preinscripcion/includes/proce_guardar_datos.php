<?php
include("conectar_pre_inscrip.php");
$codigoPreinsc = '';
$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");

$qAnio = "Select max(codiAnio) as codiAnio from TAnioTemporada";
$rAnio = mssql_query($qAnio);
$rwAnio = mssql_fetch_array($rAnio);
$anio = $rwAnio['codiAnio'];

$qTemporada = "Select max(numeTempo) as numeTempo from TAnioTemporada where codiAnio = '$anio'";
$rTemporada = mssql_query($qTemporada);
$rwTemporada = mssql_fetch_array($rTemporada);
$temporada = $rwTemporada['numeTempo'];

//echo $anio . " // " . $temporada . "////" ;

$universidad = $_POST['ddlb_uni'];
$facultad = $_POST['ddlb_facu'];
$ciclo = $_POST['ddlb_servi'];



$apePaterAlum = strtoupper(utf8_decode($_POST['apePaterAlum']));
$apeMaterAlum = strtoupper(utf8_decode($_POST['apeMaterAlum']));
$nombreAlum = strtoupper(utf8_decode($_POST['nombreAlum']));
$date = date_create($_POST['fechaNaciAlum']);
$fechaNaciAlum = date_format($date, 'd-m-Y');
$dniAlum = $_POST['dniAlum'];
$emailAlum = strtolower($_POST['emailAlum']);
$colePromoAlum = $_POST['colePromoAlum'];
$anioPromoAlum = $_POST['anioPromoAlum'];
$teleAlum = $_POST['teleAlum'];
$celuAlum = $_POST['celuAlum'];
$rpmAlum = $_POST['rpmAlum'];
$direcAlum = strtoupper(utf8_decode($_POST['direcAlum']));

$depar = $_POST['select1'];
$provin = $_POST['select2'];
$distri = $_POST['select3'];

$refeDirecAlum = strtoupper(utf8_decode($_POST['refeDirecAlum']));

$nombreApo = strtoupper(utf8_decode($_POST['nombreApo']));
$apePaterApo = strtoupper(utf8_decode($_POST['apePaterApo']));
$apeMaterApo = strtoupper(utf8_decode($_POST['apeMaterApo']));

$parenApo = $_POST['parenApo'];
$teleApo = $_POST['teleApo'];
$celuApo = $_POST['celuApo'];
$direcApo = strtoupper(utf8_decode($_POST['direcApo']));
$emailApo = strtolower($_POST['emailApo']);



include('proce_conectar_preins_aca.php');
$objPreIns = new consul_bd_aca();
$objPreIns->conectar();

//Verificar la existencia de datos de preinscripci�n

/*
$resulConsulVeri = $objPreIns->consulta("select codiPreins from preinscripcion where alupre_apep = '$apePaterAlum' and 
alupre_apem = '$apeMaterAlum' and alupre_nom = '$nombreAlum' and fecha_naci = '$fechaNaciAlum' and ciclo = '$ciclo' and universidad = '$universidad' and facultad = '$facultad'");
*/

$resulConsulVeri = $objPreIns->consulta("select codiPreInscrip from TPreInscripcionAcademia where apePaterPerso = '$apePaterAlum' and 
apeMaterPerso = '$apeMaterAlum' and nombrePerso = '$nombreAlum' and codiCicloAca = '$ciclo' and codiAnio = '$anio' and numeTempo = '$temporada'");

if ($resulConsulVeri) {
$campoResul = $objPreIns->mostrarCampos($resulConsulVeri);
$codiPI = $campoResul['codiPreInscrip'];
if( $codiPI == '')
	{	//echo "No se encontraron datos relacionados"; 
		//$resulConsul = $objPreIns->consulta("select max(codiPreins) as maxiCodi from preinscripcion");
		$resulConsul = $objPreIns->consulta("select max(codiPreInscrip) as maxiCodi from TPreInscripcionAcademia");
		$nuevoCodi =  $objPreIns->hallarNuevoCodi($resulConsul);
		$objPreIns->desconectar();
/*
		$query1 = "INSERT INTO preinscripcion (alupre_apep,alupre_apem,alupre_nom,alupre_colnom,alupre_a�oprom,alupre_collugar,alupre_dir,alupre_dis,alupre_ciu,alupre_email,ciclo,alupre_edad,alupre_lugarnaci,alupre_telealum,alupre_refedirec,alupre_provincole,alupre_deparcole,alupre_anexo,universidad,facultad,apoNombre,apoApePater,apoApeMater,apoParentesco,apoTelefono,apoDireccion,apoEmail,fecha_naci,codiPreins,enteTV,enteInter, enteRadio, enteReco, enteCarta, entePerio, enteCole, enteVolan)
		VALUES
('$apePaterAlum','$apeMaterAlum','$nombreAlum','$colePromoAlum','$anioPromoAlum','$lugarColePromo','$direcAlum','$distriDirecAlum','$provinDirecAlum','$emailAlum','$ciclo','$edadAlum','$lugarNaciAlum','$teleAlum','$refeDirecAlum','$provinColePromo','$deparColePromo','$anexoDirecAlum','$universidad','$facultad','$nombreApo','$apePaterApo','$apeMaterApo','$parenApo','$teleApo','$direcApo','$emailApo','$fechaNaciAlum', '$nuevoCodi', $enteTV,$enteInter,$enteRadio,$enteReco,$enteCarta,$entePerio,$enteCole,$enteVolan)";
*/

		$query1 = "INSERT INTO TPreInscripcionAcademia(codiPreInscrip, apePaterPerso, apeMaterPerso, nombrePerso, dniPerso, fechaNaciPerso,telePerso,celuPerso,rpmPerso,mailPerso,direcPerso,refeDirecPerso,codiDepar,codiProvin,codiDistri,codiCole,anioFinCole,apePaterApo,apeMaterApo,nombreApo,codiTipoParen,teleApo,celuApo,rpmApo,direcApo,dniApo,codiCicloAca,codiUni,codiFacu, codiAnio, numeTempo, estaMatri)
		VALUES
('$nuevoCodi','$apePaterAlum','$apeMaterAlum','$nombreAlum','$dniAlum','$fechaNaciAlum','$teleAlum','$celuAlum','$rpmAlum','$emailAlum','$direcAlum','$refeDirecAlum','$depar','$provin','$distri','$colePromoAlum','$anioPromoAlum','$apePaterApo','$apeMaterApo','$nombreApo','$parenApo','$teleApo','$celuApo','$rpmApo','$direcApo','$dniApo','$ciclo','$universidad','$facultad','$anio','$temporada', 0)";
		$result1 = mssql_query($query1); 
		$codigoPreinsc = $nuevoCodi;
	}
	else
	{
		/*
		$query2 = "UPDATE preinscripcion SET alupre_apep = '$apePaterAlum',
		alupre_apem = '$apeMaterAlum',
		alupre_nom = '$nombreAlum',
		alupre_colnom = '$colePromoAlum',
		alupre_a�oprom = '$anioPromoAlum',
		alupre_collugar = '$lugarColePromo',
		alupre_dir = '$direcAlum',
		alupre_dis = '$distriDirecAlum',
		alupre_ciu = '$provinDirecAlum',
		alupre_email = '$emailAlum',
		ciclo = '$ciclo',
		alupre_edad = '$edadAlum',
		alupre_lugarnaci = '$lugarNaciAlum',
		alupre_telealum = '$teleAlum',
		alupre_refedirec = '$refeDirecAlum',
		alupre_provincole = '$provinColePromo',
		alupre_deparcole = '$deparColePromo',
		alupre_anexo = '$anexoDirecAlum',
		universidad = '$universidad',
		facultad = '$facultad',
		apoNombre = '$nombreApo',
		apoApePater = '$apePaterApo',
		apoApeMater = '$apeMaterApo',
		apoParentesco = '$parenApo',
		apoTelefono = '$teleApo',
		apoDireccion = '$direcApo',
		apoEmail = '$emailApo',
		fecha_naci = '$fechaNaciAlum',
		enteTV = $enteTV,
		enteInter = $enteInter, 
		enteRadio = $enteRadio, 
		enteReco = $enteReco, 
		enteCarta = $enteCarta, 
		entePerio = $entePerio, 
		enteCole = $enteCole, 
		enteVolan = $enteVolan
		WHERE codiPreins = '$codiPI'";
		$result2 = mssql_query($query2);
		*/
		$query2 = "UPDATE TPreInscripcionAcademia SET apePaterPerso = '$apePaterAlum',
		apeMaterPerso = '$apeMaterAlum',
		nombrePerso = '$nombreAlum',
		dniPerso = '$dniAlum',
		fechaNaciPerso = '$fechaNaciAlum',
		telePerso = '$teleAlum',
		celuPerso = '$celuAlum',
		rpmPerso = '$rpmAlum',
		mailPerso = '$emailAlum',
		direcPerso = '$direcAlum',
		refeDirecPerso = '$refeDirecAlum',
		codiDepar = '$depar',
		codiProvin = '$provin',
		codiDistri = '$distri',		
		codiCole = '$colePromoAlum',
		anioFinCole = '$anioPromoAlum',
		apePaterApo = '$apePaterApo',
		apeMaterApo = '$apeMaterApo',
		nombreApo = '$nombreApo',
		codiTipoParen = '$parenApo',
		teleApo = '$teleApo',
		celuApo = '$celuApo',
		rpmApo = '$rpmApo',
		direcApo = '$direcApo',
		dniApo = '$dniApo',
		codiCicloAca = '$ciclo',
		codiUni = '$universidad',
		codiFacu = '$facultad'
		WHERE codiPreInscrip = '$codiPI'";
		$result2 = mssql_query($query2);
		$codigoPreinsc = $codiPI;
	}
}
else
{	echo "Error al realizar la consulta con la Base de Datos"; }

$objPreIns->desconectar();

require("reporte_pre_inscrip.php");

?>