<?php include('../piezas/seguridad.php'); ?>
<?php

	include("conectar_pre_inscrip.php");
	$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");

if(isset($_GET['buscar']) and strlen($_GET['buscar'])==8){

$qAnio = "Select max(codiAnio) as codiAnio from TAnioTemporada";
$rAnio = mssql_query($qAnio);
$rwAnio = mssql_fetch_array($rAnio);
$anio = $rwAnio['codiAnio'];

$qTemporada = "Select max(numeTempo) as numeTempo from TAnioTemporada where codiAnio = '$anio'";
$rTemporada = mssql_query($qTemporada);
$rwTemporada = mssql_fetch_array($rTemporada);
$temporada = $rwTemporada['numeTempo'];

	$qPreI = "select * from TPreInscripcionAcademia  where  numeTempo = '$temporada' AND  dniPerso = '".$_GET['buscar']."'";
	
	
}else{

	$qPreI = "select * from TPreInscripcionAcademia  where codiPreInscrip = '$codigoPreinsc'";}
$rPreI = mssql_query($qPreI);
	$rwPreI = mssql_fetch_array($rPreI);
		//LOS RESULTADOS EN SUS RESPECTIVOS POSICIONES
	
	$universidad = $rwPreI["codiUni"];
	$facultad = $rwPreI["codiFacu"];
	$ciclo =$rwPreI["codiCicloAca"];
	
	$qUni = "select nombreUni from TUniversidad where codiUni = '$universidad'";
	$rUni = mssql_query($qUni);
	$rwUni = mssql_fetch_array($rUni);
	$nombreUni = $rwUni["nombreUni"];

	$qFacu = "select nombreFacu from TFacultad where codiFacu = '$facultad'";
	$rFacu = mssql_query($qFacu);
	$rwFacu = mssql_fetch_array($rFacu);
	$nombreFacu = $rwFacu["nombreFacu"];
	
	$qCiclo = "select nombreCicloAca from TCicloPreparacionAcademia where codiCicloAca = '$ciclo'";
	$rCiclo = mssql_query($qCiclo);
	$rwCiclo = mssql_fetch_array($rCiclo);
	$nombreCiclo = $rwCiclo["nombreCicloAca"];
	
	
	$colePromoAlum =$rwPreI["codiCole"];
	
	$depar =$rwPreI["codiDepar"];
	$provin = $rwPreI["codiProvin"];
	$distri =$rwPreI["codiDistri"];
	
	$qDepar = "select nombreDepar from TDepartamento where codiDepar = '$depar'";
	$rDepar = mssql_query($qDepar);
	$rwDepar = mssql_fetch_array($rDepar);
	$nombreDepar = $rwDepar["nombreDepar"];
	
	$qProvin = "select nombreProvin from TProvincia where codiProvin = '$provin'";
	$rProvin = mssql_query($qProvin);
	$rwProvin = mssql_fetch_array($rProvin);
	$nombreProvin = $rwProvin["nombreProvin"];
	
	$qDistri = "select nombreDistri from TDistrito where codiDistri = '$distri'";
	$rDistri = mssql_query($qDistri);
	$rwDistri = mssql_fetch_array($rDistri);
	$nombreDistri = $rwDistri["nombreDistri"];
	
	
	

	$parenApo = $rwPreI["codiTipoParen"]; 
	
	
	$qParen = "select nombreTipoParen from TTipoParentesco where codiTipoParen = '$parenApo'";
	$rParen = mssql_query($qParen);
	$rwParen = mssql_fetch_array($rParen);
	$nombreParen = $rwParen["nombreTipoParen"];

	$qCole = "select nombreCole from TColegio where codiCole = '$colePromoAlum'";
	$rCole = mssql_query($qCole);
	$rwCole = mssql_fetch_array($rCole);
	$nombreCole = $rwCole["nombreCole"];
	
	
	
if($rwPreI["codiPreInscrip"]!=''){
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>---Reporte Pre Inscripcion---</title>
<link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
<link href="reporte_pre_inscrip.css" rel="stylesheet" type="text/css" />

</head>


<body class="reporte">

	

	 
<div id="cuerpoComple">
 
	<div id="Imprimir">		
		<!--<input name="" type="button" onclick="window.print()"; style="width: 150px; background:url(../../../imagenes/ima_fondo_boton.JPG)" value="Imprimir" />-->
		<a href="#" title="Imprimir ficha de Pre Inscripci�n" onclick="window.print()"></a> 
	</div>
	<div id="parteSupe">
		<div id="parteSupeIz">
			<div id="logo">
			  <img src="../imagenes/logo_preinscrip.jpg" />
			</div>
			<div id="foto">
			</div>
		</div>
		<div id="parteSupeDere">
			<div id="capaInfoParteDere">
				<div id="etiCapaParteDere">
					N&deg; de Inscripci&oacute;n:
				</div>
				<div id="objeInfoParteDere">
					
				</div>
			</div>
			<div id="capaInfoParteDere">
				<div id="etiCapaParteDere">
					Universidad / CE Sup:
				</div>
				<div id="objeInfoParteDere">
					<?php
						echo utf8_encode($nombreUni);
					?>
				</div>
			</div>
			<div id="capaInfoParteDere">
				<div id="etiCapaParteDere">
					Facultad:
				</div>
				<div id="objeInfoParteDere">
					<?php
						echo utf8_encode($nombreFacu);
					?>
				</div>
			</div>
			<div id="capaInfoParteDere">
				<div id="etiCapaParteDere">
					&Aacute;rea:
				</div>
				<div id="objeInfoParteDere1">
				</div>
				<div id="etiCapaParteDere1">
					Turno:
				</div>
				<div id="objeInfoParteDere1">
				</div>
			</div>
			<div id="capaInfoParteDere">
				<div id="etiCapaParteDere">
					Ciclo:
				</div>
				<div id="objeInfoParteDere">
					<?php
						echo utf8_encode($nombreCiclo);
					?>
				</div>
                
			</div>
		</div>
	</div>
	<div id="tituCuerpoComple">
		FICHA DE MATR&Iacute;CULA </div>
	<div id="subTituCuerpoComple">
		1. DATOS DEL ESTUDIANTE
	</div>
	<div id="datos">
		<div id="datosPostu">
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiDatos">APELLIDO PATERNO:
					</div>
					<div id="etiDatos">APELLIDO MATERNO:</div>
					<div id="etiDatos1">NOMBRES</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeDatos">
						<?php echo utf8_encode($rwPreI["apePaterPerso"]); ?>
					</div>
					<div id="objeDatos">
						<?php echo utf8_encode($rwPreI["apeMaterPerso"]); ?>
					</div>
					<div id="objeDatos1">
						<?php echo utf8_encode($rwPreI["nombrePerso"]); ?>
					</div>
				</div>
			</div>
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiFechaNaci">FECHA DE NACIMIENTO: 
					</div>
					<div id="etiEdad">DNI:
					</div>
					<div id="etiLugarNaci">E-MAIL:
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeFechaNaci"><?php
$fechanac = date_create($$rwPreI["fechaNaciPerso"]);					 echo utf8_encode(date_format($fechanac, 'd-m-Y')); ?></div>
					<div id="objeEdad"><?php echo utf8_encode($rwPreI["dniPerso"]); ?></div>
					<div id="objeLugarNaci"><?php echo utf8_encode($rwPreI["mailPerso"]); ?></div>
				</div>
			</div>
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiColeSecun">COLEGIO DONDE TERMIN&Oacute; LA SECUNDARIA:
					</div>
					<div id="etiAnio">
						A&Ntilde;O:
					</div>
					<div id="etiLugar">
						TELEFONO:
					</div>
					<div id="etiProvin">
						CELULAR:
					</div>
					<div id="etiDepar">
						RPM:
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeColeSecun">
						<?php
					
						 echo ($nombreCole); 
						if($_POST['otrocole']!='')
						{ 
						setlocale (LC_ALL, 'es_ES');
						
						echo ': '.mb_strtoupper($_POST['otrocole'],'UTF-8');
						}
						 ?>
					</div>
					<div id="objeAnio"><?php echo utf8_encode($rwPreI["anioFinCole"]); ?></div>
					<div id="objeLugar"><?php echo utf8_encode($rwPreI["telePerso"]); ?></div>
					<div id="objeProvin"><?php echo utf8_encode($rwPreI["celuPerso"]); ?></div>
					<div id="objeDepar"><?php echo utf8_encode($rwPreI["rpmPerso"]); ?></div>
				</div>
			</div>
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiDirecActual">DIRECCI&Oacute;N ACTUAL DEL ALUMNO: 
					</div>
					<div id="etiAnexo">DPTO:
					</div>
					<div id="etiDistri">PROVINCIA:
					</div>
					<div id="etiProvinAlum">DISTRITO:
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeDirecActual"><?php echo utf8_encode($rwPreI["direcPerso"]); ?></div>
					<div id="objeAnexo">
						<?php echo utf8_encode($nombreDepar); ?>
					</div>
					<div id="objeDistri">
						<?php echo ($nombreProvin); ?>
					</div>
					<div id="objeProvinAlum">
						<?php echo ($nombreDistri); ?>
					</div>
				</div>
			</div>
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiRefe">REFERENCIA:
					</div>
					<div id="etiTele">
					</div>
					<div id="etiEmail">
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeRefe"><?php echo utf8_encode($rwPreI["refeDirecPerso"]); ?></div>
					<div id="objeTele">
						<?php //echo $teleAlum; ?>
					</div>
					<div id="objeEmail">
						<?php //echo $emailAlum; ?>
					</div>
				</div>
			</div>
		</div>
		<div id="subTituCuerpoComple">
			2. DATOS DEL PADRE O APODERADO
		</div>
		<div id="datosApo1">
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiDatosApo">
						APELLIDOS Y NOMBRES:
					</div>
					<div id="etiParenApo">
						PARENTESCO:
					</div>
					<div id="etiTeleApo">
						TEL&Eacute;FONO:
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeDatosApo"><?php echo utf8_encode($rwPreI["apePaterApo"].' '.$rwPreI["apeMaterApo"].', '.$rwPreI["nombreApo"]); ?></div>
					<div id="objeParenApo">
						<?php echo ($nombreParen); ?>
					</div>
					<div id="objeTeleApo"><?php echo utf8_encode($rwPreI["teleApo"]); ?></div>
				</div>
			</div>
			<div id="capaDatosPostu">
				<div id="etiCapaDatosPostu">
					<div id="etiDirecApo">DIRECCI&Oacute;N:
					</div>
					<div id="etiEmailApo">
						EMAIL:
					</div>
				</div>
				<div id="objeCapaDatosPostu">
					<div id="objeDirecApo"><?php echo utf8_encode($rwPreI["direcApo"]); ?></div>
					<div id="objeEmailApo"><?php //echo utf8_encode($rwPreI["mail"]); ?></div>
				</div>
			</div>
			<div id="capaDatosPostu1">
				<!--<div id="etiCapaDatosPostu">
					<div id="mensaje">
						(LLENAR SOLO EN CASO DEL PADRE O APODERADO)
					</div>
				</div> -->
				<div id="objeCapaObser">
					<div id="etiObser">
						OBSERVACIONES:
					</div>
					<div id="objeObser">
					</div>
					<div id="objeDia">
					</div>
					<div id="objeMes">
					</div>
					<div id="objeAnio1">
					</div>
				</div>
				<div id="firmaPadre">
					<div id="firmaAlum">
						<div id="objeFirma">
						</div>
						<div id="etiFirma">
							--------------------------------------------------<br />

							Firma del Alumno
						</div>
					</div>
					<div id="firmaApo">
						<div id="objeFirma">
						</div>
						<div id="etiFirma">
							--------------------------------------------------<br />
							Firma del Apoderado
						</div>
					</div>
					<div id="firmaSecre">
						<div id="objeFirma">
						</div>
						<div id="etiFirma">
							--------------------------------------------------<br />
							Secretar&iacute;a
						</div>
					</div>
				</div>
				<div id="mensaje1">
					<span class="mensaje">De conformidad con el D.L. 691 y D.L. 706. El alumno (ciudadano) y/o apoderado que suscriben la presente autorizan en caso de ingreso a una de las universidades del Per&uacute;, usar su imagen para fines de publicidad.</span>
				</div>
               
			</div>
		</div>
		<div id="corte_repor_aca">
		</div>
		<div id="datosPostuPie">
			     <div id="mensaje1">
					<span class="mensaje">Registro Web: <?php
															date_default_timezone_set('America/Lima');
															echo utf8_encode(date('d/m/Y�H:i:s'));
															?>
                    </span> 
				</div>
				</div>
		</div>
	</div>
	
</div>
</body>
</html>
<?php }else{?>
       <div class="layout-item-2" style="width: 100%; background-color:#FFE6E6; padding:2px; color: #903;;text-align: center; font-size:14px" >
       
       <div  style="text-align:center"><strong>Nota: </strong></div>
      * No estas registrado en &eacutesta <strong>ultima temporada</strong><br />

<br />

     * PRE INSCRIBIRTE a cualquiera de nuestros ciclos y obtener autom&aacuteticamente un descuento de S/. 60.00, solo debes rellenar tus datos, imprimir la ficha y entregarla al momento de tu matr&iacutecula en nuestra oficina de informes.
   <br>
     </div>
    </div>
<?php }?>