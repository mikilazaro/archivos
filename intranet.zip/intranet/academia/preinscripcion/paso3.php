<?php include('piezas/seguridad.php'); 
if(isset($_POST['dniAlum']))
{
 ?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Pre Inscripción (Paso3) - Academia Ingeniería</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="estilos/style.css" media="screen">
    <link rel="stylesheet" href="estilos/style.responsive.css" media="all">
    <link rel="icon" href="estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="estilos/jquery.js"></script>
    <script src="estilos/script.js"></script>
    <script src="estilos/script.responsive.js"></script>
     
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php //include('piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                                                  
                        <div class="art-postcontent art-postcontent-0 clearfix">
             
  
  <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row" style="background-image:url(estilos/images/paso3.png); background-repeat: no-repeat; background-position:left; background-size:100%" >
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
                <div > 

<br>
<br>


 </div> 
    </div>
    </div>
</div>
</div>
 <form action="includes/proce_guardar_datos.php" id="frm_Pre_Inscrip" name="frm_Pre_Inscrip" method="POST">
                      <div class="art-content-layout-wrapper layout-item-0"  >
                      
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 70%" >
        <h3 style="text-align: center;padding-bottom: 10px;border-bottom:1px solid #d9d0c9">3. DATOS DE UNO DE LOS PADRES O APODERADO</h3>
    </div>
    </div>
</div>
</div>
<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 50%" >
    <ul>
      <li style="text-align: left;"><strong><span>Parentesco: *</span></strong></li></ul>
        <?php
	include("includes/conectar_pre_inscrip.php");
	$qParentesco = "SELECT codiTipoParen, nombreTipoParen FROM TTipoParentesco order by nombreTipoParen";
	$rParentesco = mssql_query($qParentesco);
echo "<select name='parenApo' autofocus required id='parenApo' style='width:100%' >";
							echo "<option value=''>Elige</option>";
											while($reParen=mssql_fetch_row($rParentesco))
											{
							 echo "<option value='".$reParen["0"]."'>".$reParen['1']."</option>";
											}
											echo "</select>";
										?>
        <br>
      <ul>
        <li style="text-align: left;"><strong><span>Apellido Paterno: *</span></strong></li></ul>
 
        <input name="apePaterApo" required type="text"  value=""/>
        <br>
        <ul>
          <li style="text-align: left;"><strong><span>Apellido Materno</span>: *</strong> </li></ul>
 
        <input name="apeMaterApo" required type="text"  value=""/>
        <br>
        <ul>
          <li style="text-align: left;"><strong><span> Nombres</span> *</strong> </li></ul>
 
        <input name="nombreApo" required type="text"  value=""/>
        <br>
         
    </div><div class="art-layout-cell layout-item-2" style="width: 50%" >
      
        
          <ul><li style="text-align: left;"><strong><span>Teléfono :</span></strong> </li></ul>
 
          <input name="teleApo" type="text"  value=""/>
          <br>
          <ul><li style="text-align: left;"><strong><span>Celular :</span></strong> </li></ul>
 
          <input name="celuApo" type="text"   value=""/>
          <br>
           <ul>
             <li style="text-align: left;"><strong><span>DirecciÓn :</span></strong> </li></ul>
 
          <input name="direcApo" type="text"   value=""/>
          <br>
    </div>
    </div>
</div>
</div>
<br>

<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
    <a class="art-button"  href=javascript:history.back(1)>Atras</a>
       <input class="art-button" type="submit" name="btnpaso" id="btnpaso" value="Listo! Pre Inscríbete">
    </div>
    </div>
</div>
</div>

<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%; background-color:#FFE6E6; text-align:center; padding:5px; color: #903;" >
       
       <div  style="text-align:center"><strong>Nota: </strong></div>
        * Despues de grabar IMPRIME la ficha y entrega al momento de tu matrícula en nuestra oficina de informes.
    </div>

    
    </div>
</div>
</div>
<!--Datos recibidos desde paso1-->
<input name="ddlb_uni" type="hidden"  value="<?php echo $_POST['ddlb_uni']; ?>"/>
<input name="ddlb_facu" type="hidden"  value="<?php echo $_POST['ddlb_facu']; ?>"/>
<input name="ddlb_servi" type="hidden"  value="<?php echo $_POST['ddlb_servi']; ?>"/>
<input name="dniAlum" type="hidden"  value="<?php echo $_POST['dniAlum']; ?>"/>
<input name="apePaterAlum" type="hidden"  value="<?php echo $_POST['apePaterAlum']; ?>"/>
<input name="apeMaterAlum" type="hidden"  value="<?php echo $_POST['apeMaterAlum']; ?>"/>
<input name="nombreAlum" type="hidden"  value="<?php echo $_POST['nombreAlum']; ?>"/>
<input name="fechaNaciAlum" type="hidden"  value="<?php echo $_POST['fechaNaciAlum']; ?>"/>
<input name="emailAlum" type="hidden"  value="<?php echo $_POST['emailAlum']; ?>"/>
<input name="select1" type="hidden"  value="<?php echo $_POST['select1']; ?>"/>
<input name="select2" type="hidden"  value="<?php echo $_POST['select2']; ?>"/>
<input name="select3" type="hidden"  value="<?php echo $_POST['select3']; ?>"/>
<input name="direcAlum" type="hidden"  value="<?php echo $_POST['direcAlum']; ?>"/>
<input name="refeDirecAlum" type="hidden"  value="<?php echo $_POST['refeDirecAlum']; ?>"/>
  <!--Datos recibidos desde paso2--> 
  <input name="colePromoAlum" type="hidden"  value="<?php echo $_POST['colePromoAlum']; ?>"/>
  <input name="otrocole" type="hidden"  value="<?php echo $_POST['otrocole']; ?>"/>
  <input name="anioPromoAlum" type="hidden"  value="<?php echo $_POST['anioPromoAlum']; ?>"/>
  <input name="teleAlum" type="hidden"  value="<?php echo $_POST['teleAlum']; ?>"/>
  <input name="celuAlum" type="hidden"  value="<?php echo $_POST['celuAlum']; ?>"/>
  <input name="rpmAlum" type="hidden"  value="<?php echo $_POST['rpmAlum']; ?>"/>
   
</form>
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<?php }else{
	echo	header('location: index.php');
}?>