<?php include('piezas/seguridad.php'); 
if(isset($_POST['dniAlum']))
{
 ?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Pre Inscripción (Paso2) - Academia Ingeniería</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="estilos/style.css" media="screen">
    <link rel="stylesheet" href="estilos/style.responsive.css" media="all">
    <link rel="icon" href="estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="estilos/jquery.js"></script>
    <script src="estilos/script.js"></script>
    <script src="estilos/script.responsive.js"></script>
    <script src="includes/cargarcolegio.js"></script>
    
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php //include('piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                                                   
                        <div class="art-postcontent art-postcontent-0 clearfix">
                    
 
  <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row" style="background-image:url(estilos/images/paso2.png); background-repeat: no-repeat; background-position:left; background-size:100%" >
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
                <div > 

<br>
<br>


 </div> 
    </div>
    </div>
</div>
</div>           
      
            <form action="paso3.php" id="frm_Pre_Inscrip" name="frm_Pre_Inscrip" method="POST">  
                    <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
        <h3 style="text-align: center;padding-bottom: 10px;border-bottom:1px solid #d9d0c9">2. EDUCACIÓN</h3>
         <ul>
   <li style="text-align: left;"><strong><span>
   <label id="labelselectdepa" name = "labelselectdepa">Departamento donde actualmente estudia o terminó: *</label></span></strong></li></ul>
<?php
 
 include("includes/conectar_pre_inscrip.php");
$res=mssql_query("select * from TDepartamento");
 
?>
 
<select id="depacolegio" required autofocus onchange="cargarprovincia(this.value)" style='width:270px; '>
 
<option value="">Seleccione</option>
 
<?php
 
while($fila=mssql_fetch_array($res)){
 
?>
 
<option value="<?php echo $fila['codiDepar']; ?>"><?php echo utf8_encode($fila['nombreDepar']); ?></option>
 
<?php } ?>
 
</select>

 <ul><li style="text-align: left;"><strong><span>Provincia donde actualmente estudia o terminó: *</span></strong></li></ul>
  
<div id="divprovincia"><select id="coleprov" required onchange="load(this.value)" style='width:270px; ' >
 
<option value="">Seleccione Provincia</option>
 
 
 
</select></div>
       
       
 <ul><li style="text-align: left;"><strong><span> Colegio en el que estudia o terminó: *</span></strong></li></ul>
  
<div id="myDiv"><select id="colegio" required   style='width:270px; '  >
 
<option value="">Seleccione colegio</option>
 
 
<option value=""   >-Primero seleccione Provincia-</option>
 

 
</select></div>

<div id="divotrocole" style=" display:none" > 
<ul><li style="text-align: left;"><strong><span> Nombre del Colegio: *</span></strong></li></ul>
  
<input  name="otrocole" required  id="otrocole" type="text"  value=""/>

</div>
       
       
<ul>
<li style="text-align: left;"><strong><span>¿Finalizó sus estudios?:</span></strong> <input id="finestudio"  type="checkbox" onclick="document.frm_Pre_Inscrip.anioPromoAlum.disabled=!document.frm_Pre_Inscrip.anioPromoAlum.disabled;document.frm_Pre_Inscrip.anioPromoAlum.value='';" value="" checked="CHECKED"><label for="finestudio">Si</label> </li></ul> 
 <ul> <li style="text-align: left;"><strong><span> Año que finalizó sus estudios: </span></strong> </li></ul>
 
        <input  name="anioPromoAlum"  id="anioPromoAlum" type="number" min="1990" max="<?php echo date('Y') ?>" value=""/>
        <br>
<ul>
  <li style="text-align: left;"><strong><span>Teléfono:</span></strong> </li></ul>
 
        <input name="teleAlum"  type="text"  value=""/>
        <br>
<ul>
  <li style="text-align: left;"><strong><span>Celular:</span></strong> </li></ul>
 
        <input name="celuAlum" type="number" min="900000000" max="999999999" value=""/>
        <br>
<ul>
  <li style="text-align: left;"><strong><span>RPM/ rpc/ rpb/ rpe:</span></strong> </li></ul>
 
        <input name="rpmAlum" type="text" value=""/>
        <br>


    </div>
    </div>
</div>
</div>
             
                  <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%; text-align:right" >
    <a class="art-button" href="javascript:history.back()">Atras</a>
       <input class="art-button" type="submit" name="btnpaso" id="btnpaso" value="Siguiente">
    </div>
    </div>
</div>
</div>
<!--Datos recibidos desde paso1-->
<input name="ddlb_uni" type="hidden"  value="<?php echo $_POST['ddlb_uni']; ?>"/>
<input name="ddlb_facu" type="hidden"  value="<?php echo $_POST['ddlb_facu']; ?>"/>
<input name="ddlb_servi" type="hidden"  value="<?php echo $_POST['ddlb_servi']; ?>"/>
<input name="dniAlum" type="hidden"  value="<?php echo $_POST['dniAlum']; ?>"/>
<input name="apePaterAlum" type="hidden"  value="<?php echo $_POST['apePaterAlum']; ?>"/>
<input name="apeMaterAlum" type="hidden"  value="<?php echo $_POST['apeMaterAlum']; ?>"/>
<input name="nombreAlum" type="hidden"  value="<?php echo $_POST['nombreAlum']; ?>"/>
<input name="fechaNaciAlum" type="hidden"  value="<?php echo $_POST['fechaNaciAlum']; ?>"/>
<input name="emailAlum" type="hidden"  value="<?php echo $_POST['emailAlum']; ?>"/>
<input name="select1" type="hidden"  value="<?php echo $_POST['select1']; ?>"/>
<input name="select2" type="hidden"  value="<?php echo $_POST['select2']; ?>"/>
<input name="select3" type="hidden"  value="<?php echo $_POST['select3']; ?>"/>
<input name="direcAlum" type="hidden"  value="<?php echo $_POST['direcAlum']; ?>"/>
<input name="refeDirecAlum" type="hidden"  value="<?php echo $_POST['refeDirecAlum']; ?>"/>

   </form>  
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html><?php }else{
	echo	header('location: index.php');
}?>