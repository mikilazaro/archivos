<?php
// Array que vincula los IDs de los selects declarados en el HTML con el nombre de la tabla donde se encuentra su contenido
$listadoSelects=array(
"select1"=>"TDepartamento",
"select2"=>"TProvincia",
"select3"=>"TDistrito"
);

function validaSelect($selectDestino)
{
	// Se valida que el select enviado via GET exista
	global $listadoSelects;
	if(isset($listadoSelects[$selectDestino])) return true;
	else return false;
}

function validaOpcion($opcionSeleccionada)
{
	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor numerico
	if(is_numeric($opcionSeleccionada)) return true;
	else return false;
}

$selectDestino=$_GET["select"];
$opcionSeleccionada=$_GET["opcion"];
$opcionSeleccionada1=$_GET["opcion1"];

//echo $selectDestino.' '.$opcionSeleccionada;

if(validaSelect($selectDestino) /*&& validaOpcion($opcionSeleccionada)*/)
{
	$tabla=$listadoSelects[$selectDestino];

	include("includes/conectar_pre_inscrip.php");
	$db_link = mssql_select_db($db,$link) or die ("El Nombre de la base de datos no es correcto");

	if ($tabla == 'TProvincia')
	{
		$consulta=mssql_query("SELECT codiProvin, nombreProvin FROM $tabla WHERE codiDepar='$opcionSeleccionada'");
	}
	else
	{
		if ($tabla == 'TDistrito')
		{
			$consulta=mssql_query("SELECT codiDistri, nombreDistri FROM $tabla WHERE codiProvin='$opcionSeleccionada' and codiDepar = '$opcionSeleccionada1'");
		}
	}

	// Comienzo a imprimir el select
	echo "<select required name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' style='width:100%; '>";
	echo "<option value=''>Elige</option>";
	while($registro=mssql_fetch_row($consulta))
	{
		// Convierto los caracteres conflictivos a sus entidades HTML correspondientes para su correcta visualizacion
		$registro[1]=htmlentities($registro[1]);
		// Imprimo las opciones del select
		echo "<option value='".$registro[0]."'>".$registro[1]."</option>";
	}			
	echo "</select>";
}
?>