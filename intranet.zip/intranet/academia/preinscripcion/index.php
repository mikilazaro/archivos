 <?php include('piezas/seguridad.php'); ?>
    <!DOCTYPE html>
<html dir="ltr" lang="en-US"><head>
    <meta charset="utf-8">
    <title>Pre Inscripción - Academia Ingeniería</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <link rel="stylesheet" href="estilos/style.css" media="screen">
    <link rel="stylesheet" href="estilos/style.responsive.css" media="all">
    <link rel="icon" href="estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="estilos/jquery.js"></script>
    <script src="estilos/script.js"></script>
    <script src="estilos/script.responsive.js"></script>
<script type="text/javascript" src="select_dependientes_3_niveles.js"></script>

</head>
<body>
<div id="art-main">
<?php include('piezas/cabecera.php'); ?>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <?php //include('piezas/bloque.php'); ?>
                        <div class="art-layout-cell art-content">
                          <article class="art-post art-article">
                        
<div  class="layout-item-2" style="width: 100%;  background-color:#FFE6E6; font-size:11px; padding:5px" >
       <div  style="text-align:center"><strong>Nota: </strong></div>
* PRE INSCRIBIRTE a cualquiera de nuestros ciclos y obtener automáticamente un descuento de S/. 60.00, solo debes rellenar tus datos, imprimir la ficha y entregarla al momento de tu matrícula en nuestra oficina de informes.
<br>

  * <strong>Los casilleros marcadas con (*)</strong>, son datos indispensables para realizar la pre inscripción. <br>
<em>* Si ya te has registrado antes, <a href="buscar.php"><strong>BUSCAR TU FICHA AQUI</strong></a></em>
</div>        
                                <div class="art-postcontent art-postcontent-0 clearfix">
           
 
  <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row" style="background-image:url(estilos/images/paso1.png); background-repeat: no-repeat; background-position:left; background-size:100%" >
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
                <div > 

<br>
<br>


 </div> 
    </div>
    </div>
</div>
</div>
      <form action="paso2.php" id="frm_Pre_Inscrip" name="frm_Pre_Inscrip" method="POST">                          
                                <div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
        <h3 style="text-align: center;padding-bottom: 10px;border-bottom:1px solid #d9d0c9">PRE INSCRIPCIÓN	- CICLOS DE PREPARACIÓN 2016</h3>
      
        <ul>
          <li style="text-align: left;"><strong><span>Universidad/Centro Educ. Superior:*</span></strong> 
        <?php
										include("includes/conectar_pre_inscrip.php");
										$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");
										$queryUni = "SELECT codiUni, nombreUni FROM TUniversidad where serviAcaUni = 1 order by nombreUni ASC";
										$resultUni = mssql_query($queryUni);
										echo "<select autofocus required  name='ddlb_uni' id='ddlb_uni' style=\"width:257px;\">";
										echo "<option  value=''>-- Elige. --</option>";
										while($rowUni=mssql_fetch_array($resultUni))
										{
											echo "<option value='".$rowUni['codiUni']."'>[ ".utf8_encode($rowUni['nombreUni']). " ]</option>";
										}
										echo "</select>";
									?>
        </li></ul>
        <ul>
          <li style="text-align: left;"><strong><span>Seleccione Facultad/Especialidad :*&nbsp; </span></strong> 
        <?php
										$queryFacu = "SELECT codiFacu, nombreFacu FROM TFacultad where estaFacu = 1";
										$resultFacu = mssql_query($queryFacu);
										echo "<select required  name='ddlb_facu' id='ddlb_facu' style=\"width:257px;\">";
										echo "<option value=''>-- Elige. --</option>";
										while($rowFacu=mssql_fetch_array($resultFacu))
										{
											echo "<option value='".$rowFacu['codiFacu']."'>".utf8_encode($rowFacu['nombreFacu'])."</option>";
										}
										echo "</select>";
									?>
       </li></ul> 
<ul>
  <li style="text-align: left;"><strong><span>Seleccione Ciclo de preparación:*&nbsp; &nbsp; &nbsp;</span></strong> 
<?php
										$qAnio = "Select max(codiAnio) as codiAnio from TAnioTemporada";
										$rAnio = mssql_query($qAnio);
										$rwAnio = mssql_fetch_array($rAnio);
										$anio = $rwAnio['codiAnio'];
									
										$qTemporada = "Select max(numeTempo) as numeTempo from TAnioTemporada where codiAnio = '$anio'";
										$rTemporada = mssql_query($qTemporada);
										$rwTemporada = mssql_fetch_array($rTemporada);
										$temporada = $rwTemporada['numeTempo'];
									
										$queryServi = "SELECT DISTINCT dbo.TCicloPreparacionAcademia.codiCicloAca, dbo.TCicloPreparacionAcademia.nombreCicloAca FROM dbo.TProgramaAcademia INNER JOIN dbo.TCicloPreparacionAcademia ON dbo.TProgramaAcademia.codiCicloAca = dbo.TCicloPreparacionAcademia.codiCicloAca WHERE (dbo.TProgramaAcademia.codiAnio = '$anio') AND (dbo.TProgramaAcademia.numeTempo = '$temporada') AND (dbo.TProgramaAcademia.codiCicloAca <> 'CA000011')";
										$resultServi = mssql_query($queryServi);
										echo "<select required   name='ddlb_servi' id='ddlb_servi' style=\"width:257px;\">";
										echo "<option value=''>-- Elige. --</option>";
										while($rowServi=mssql_fetch_array($resultServi))
										{
											echo "<option value='".$rowServi['codiCicloAca']."'>".utf8_encode($rowServi['nombreCicloAca'])."</option>";
										}
										echo "</select>";
									?></li></ul>


   

    </div>
    </div>
</div>
</div>
<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%" >
        <h3 style="padding-bottom: 10px; text-align: center; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(217, 208, 201);">1. DATOS DEL ESTUDIANTE</h3>
    </div>
    </div>
</div>
</div>
<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 50%" >
        <h3 style="padding-bottom: 10px; border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(217, 208, 201); text-align: center;">Datos personales</h3>
        
      <ul> <li style="text-align: left;"><strong><span>DNI: *</span></strong></li></ul>

        <input name="dniAlum" type="number" required  value="" min="10000000" max="99999999"/>
        <br>

<ul>
  <li style="text-align: left;"><strong><span> Apellido Paterno: *</span></strong></li>
</ul>

        <input name="apePaterAlum" id="sle_apePaterAlum" type="text"  required value=""/>
        <br>
    <ul>    <li style="text-align: left;"><strong><span> Apellido Materno: *</span></strong> </li>
        </ul>

        <input name="apeMaterAlum" id="sle_apeMaterAlum" type="text" required value=""/>
        <br>
        <ul>
          <li style="text-align: left;"><strong><span> Nombre Completo: *</span></strong></li>
        </ul>

   
        <input name="nombreAlum" id="sle_nombreAlum" type="text"  required  value=""/>
        <br>
       <ul>   <li style="text-align: left;"><strong><span>Fecha de Nacimiento:</span></strong> </li>
        </ul>

   
        <input name="fechaNaciAlum" placeholder="dia/mes/año" type="date" value="" />
        <br>
         <ul><li style="text-align: left;"><strong><span style="font-weight: bold;">E-mail:</span></strong> </li>
      </ul>
          <input name="emailAlum" id="sle_emailAlum" type="email"  value=""/>
    </div>
    <div class="art-layout-cell layout-item-2" style="width: 50%" >
        <h3 style="text-align: center;padding-bottom: 10px;border-bottom:1px solid #d9d0c9">Datos de residencia</h3>
                <ul> 
          <li style="text-align: left;"><strong><span> Departamento: *&nbsp;</span></strong> 
            <select name='select1' id='select1' onChange='cargaContenido(this.id)' required style='width:100%;'>
            <option value=''>-Elige Departamento--</option>
            <option value='D06'>AMAZONAS</option>
            <option value='D07'>ANCASH</option>
            <option value='D08'>APURIMAC</option>
            <option value='D09'>AREQUIPA</option>
            <option value='D10'>AYACUCHO</option>
            <option value='D11'>CAJAMARCA</option>
            <option value='D12'>CALLAO</option>
            <option value='D13'>CUSCO</option>
            <option value='D04'>HUANCAVELICA</option>
            <option value='D03'>HUANUCO</option>
            <option value='D14'>ICA</option>
            <option value='D01'>JUNÍN</option>
            <option value='D15'>LA LIBERTAD</option>
            <option value='D16'>LAMBAYEQUE</option>
            <option value='D02'>LIMA</option>
            <option value='D17'>LORETO</option>
            <option value='D18'>MADRE DE DIOS</option>
            <option value='D19'>MOQUEGUA</option>
            <option value='D26'>NINGUNO</option>
            <option value='D05'>PASCO</option>
            <option value='D20'>PIURA</option>
            <option value='D21'>PUNO</option>
            <option value='D22'>SAN MARTIN</option>
            <option value='D23'>TACNA</option>
            <option value='D24'>TUMBES</option>
            <option value='D25'>UCAYALI</option>
      </select></li></ul>
        
        <ul>
          <li><span style="font-weight: bold;"> Provincia: *&nbsp; </span>
          <span>  
          <select required  name="select2" id="select2" style="width:100%; ">
            <option value="">Selecciona opci&oacute;n...</option>
          </select></span>
        </li></ul>
        <ul>
          <li><span style="font-weight: bold;"> Distrito: * &nbsp;&nbsp; </span>
           <span>  
           <span style="font-weight: bold;">&nbsp;</span>
           <select required  name="select3" id="select3" style="width:100%; ">
            <option value="">Selecciona opci&oacute;n...</option>
          </select></span>
       </li></ul>
      <ul>
        <li style="text-align: left;"><strong><span style="font-weight: bold;"> Dirección actual: *</span></strong></li>
      </ul>
        <input required name="direcAlum" id="sle_direcAlum" type="text"  value=""/>
     
     
        <ul><li><span style="font-weight: bold;">Referencia:</span></li></ul>
        <textarea name="refeDirecAlum"></textarea>
        
    </div>
    </div>
</div>
</div>

<div class="art-content-layout-wrapper layout-item-0">
<div class="art-content-layout layout-item-1">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-2" style="width: 100%; text-align: right"  >
      
          <input class="art-button" type="submit" name="btnpaso" id="btnpaso" value="Sieguiente">
 
    </div>
    </div>
</div>
</div>
</form>
</div>
                                
                

</article></div>
                    </div>
                </div>
            </div>
    </div>
<!--Inicio pie de página-->
<?php include('piezas/pie.php'); ?>
<!--Fín pie de página-->

</div>


</body></html>