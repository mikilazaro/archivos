<? 
session_start();
 include('../piezas/seguridad.php');
if ($_SESSION['validado'] == 'ok') {
$codi_usua_intra = $_SESSION['codiUsua'];
$usua_intra_cei = $_SESSION['nombreAlum'] . " " . $_SESSION['apaPaterAlum'] . " " . $_SESSION['apaMaterAlum'];

if (isset($_POST['cb_enviar'])) 
{
	$contraActualIngre = $_POST['sle_contra_actual'];
	$nuevaContra = $_POST['sle_contra_nueva'];
	$confirNuevaContra = $_POST['sle_confir_contra_nueva'];
	

	include("includes/conectar_academia_nuevo.php");
		$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");
	$sql = "Select contraAlum from TAlumnoAcademia where codiAlum = '$codi_usua_intra'";
	$result =  mssql_query($sql);
	//$vector = $bd_sgi->registro($result);
	$vector = mssql_fetch_array($result);
	$contraActual = $vector[0];
	if ($contraActual == $contraActualIngre) 
	{
		$mensa = "Contraseña actual valida"; 
		if ($nuevaContra == $confirNuevaContra) 
		{
			if (strlen($nuevaContra)<6) { $mensa = "Contraseña muy corta, debe tener como mínimo 6 caracteres."; }
			else {
			//$nuevaContra = crc32($nuevaContra);
			//$nuevaContra = $nuevaContra;
			
			$sql = "Update TAlumnoAcademia set contraAlum = '$nuevaContra' where codiAlum = '$codi_usua_intra'";
			$result = mssql_query($sql);
			$sql2 = "SELECT codiPersona FROM TAlumno WHERE codiAlum = '$codi_usua_intra'";
			$result2 = mssql_query($sql2);
			$vector2 =mssql_fetch_array($result2);
			$codiPersoAlum = $vector2[0];
			$sql3 = "SELECT MAX(codiCambioContra) FROM TCambioContraAlumAca";
			$result3 = mssql_query($sql3);
			$vector3 = mssql_fetch_array($result3);
			$ls_codi = $vector3[0];
			$ldt_fechaActu = date("Y/m/d H:i:s");
//			$ldt_fechaActu = '2014-07-30 10:00:05.773';
			//echo $ldt_fechaActu . ' //// ';
			$ls_codiAlumCambio = substr("00000". strval(intval($ls_codi) + 1),-6);
			$sql1 = "INSERT INTO TCambioContraAlumAca(codiCambioContra, codiPersoAlum, contraOri, contraCambio, fechaCambioContra, motiCambioContra, codiPersoCambio) VALUES('$ls_codiAlumCambio', '$codiPersoAlum' , '$contraActual', '$nuevaContra', '$ldt_fechaActu', 'Cambio desde extranet', '$codiPersoAlum')";
			$resultA = mssql_query($sql1);
			//echo $codi_usua_intra . ' / ' .$ls_codiAlumCambio . '-' . $codiPersoAlum . '-' . $contraActual. '-' . $nuevaContra . '////  ';
			//echo date("Y-m-d H:i:s");
			if ($result)
			{$mensa = '<span class="art-comment-header">Se cambió la contraseña en forma satisfactoria</span>';}
			}
		}
		else { $mensa = '<span class="art-comment-content">La confirmacion de la nueva contraseña no coincide verifique</span>';}
	}
	else { $mensa = '<span class="art-comment-content">La contraseña actual no es correcta';}
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Título de la página</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
   <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
     <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article" >
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">Cambiar Contraseña</span></h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix" style="width:100%; text-align:center">
                        

                        <form action="cambiar-clave.php" method="post" name="formu_cambiar_contra">
                        Contraseña actual:<br>

						  <input name="sle_contra_actual" type="password" style="width:300px;" />
						  <br>
						  Nueva contraseña:<br>
                          <input name="sle_contra_nueva" type="password" style="width:300px;" />
                          </span><br>
                          Confirme nueva contraseña:<br>
                           <input name="sle_confir_contra_nueva" type="password" style="width:300px;" /><br>

                          <input name="cb_enviar" type="submit" class="art-button" value="Aceptar" />
                         <br>

                          <? echo $mensa; ?>
					      </form>
                     
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<? 
}
else
{ header('location: ../intranet/index.php');
  echo "No ha validado su sessión";
}
?>