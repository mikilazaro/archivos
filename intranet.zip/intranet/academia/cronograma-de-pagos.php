<? 
session_start();
 include('../piezas/seguridad.php');
if ($_SESSION['validado'] == 'ok') {
$codi_usua_intra = $_SESSION['codiUsua'];
$usua_intra_cei = $_SESSION['nombreAlum'] . " " . $_SESSION['apaPaterAlum'] . " " . $_SESSION['apaMaterAlum'];
include("includes/conectar_academia_nuevo.php");
$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");

$codiMatriAca = '';
if(isset($_POST['codiMatriAca'])) 
			{
				$codiMatriAca = $_POST['codiMatriAca']; 
			}else{
				$qPerioLectiAlum = "Select max(codiMatriaca) as codiMatriAca from TMatriculaAcademia where codiAlum = '".$codi_usua_intra."'";
					$rPerioLectiAlum = mssql_query($qPerioLectiAlum);
					$rowPerioLectiAlum = mssql_fetch_array($rPerioLectiAlum);

					$codiMatriAca = $rowPerioLectiAlum['codiMatriAca'];
			}
  $sqlhistorial="select TDerechoPago.nombreDerePago,TDetalleDeudaAcademia.numeCuota, TDetalleDeudaAcademia.estaCuota, TDetalleDeudaAcademia.montoPagoDeuda, TDetalleDeudaAcademia.fechaPago
  from TDetalleDeudaAcademia inner join TDeudaAcademia on TDetalleDeudaAcademia.codiDeudaAca= TDeudaAcademia.codiDeudaAca 
inner join TDerechoPago on TDeudaAcademia.codiDerePago = TDerechoPago.codiDerePago
 where TDeudaAcademia.codiMatriAca = '".$codiMatriAca."'
 order by TDetalleDeudaAcademia.codiDetaDeudaAca desc";
			   $rhistorial = mssql_query($sqlhistorial);

			   $canthistorial=mssql_num_rows($rhistorial);
			   
			
			   
?>

<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Cronograma de pagos</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
    <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
  <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>
    
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">Cronograma de pagos</span></h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix">
                         <form action="" method="post" name="formu_opcio">
                <?php
						$consultaQuery = "SELECT dbo.TMatriculaAcademia.codiMatriAca, dbo.TCicloPreparacionAcademia.nombreCicloAca + '     ' + dbo.TAnio.nombreAnio + '-' + CAST(dbo.TProgramaAcademia.numeTempo AS varchar) + '      ' + UPPER(dbo.TTurno.nombreTurno) AS ciclo FROM         dbo.TMatriculaAcademia INNER JOIN dbo.TProgramaAcademia ON dbo.TMatriculaAcademia.codiPrograAca = dbo.TProgramaAcademia.codiPrograAca INNER JOIN dbo.TCicloPreparacionAcademia ON dbo.TProgramaAcademia.codiCicloAca = dbo.TCicloPreparacionAcademia.codiCicloAca INNER JOIN                    dbo.TAnio ON dbo.TProgramaAcademia.codiAnio = dbo.TAnio.codiAnio INNER JOIN dbo.TTurno ON dbo.TProgramaAcademia.codiTurno = dbo.TTurno.codiTurno WHERE (dbo.TMatriculaAcademia.codiAlum = '$codi_usua_intra') ORDER BY dbo.TMatriculaAcademia.fechaMatri DESC;";


					$consulta = mssql_query($consultaQuery);
				

				?>
                <strong> Selecciona ciclo académico :</strong>
<select name="codiMatriAca" id="codiMatriAca" onChange="this.form.submit()">
            <option value='0'>-- Seleccione --</option>
                                       <?php while($registro=mssql_fetch_array($consulta))
					{	
						?>
                                       <OPTION value="<?php echo $registro['codiMatriAca'];?>" <?php if ( $registro['codiMatriAca'] == $codiMatriAca  ) { echo 'selected';}?>   ><?php echo utf8_encode($registro['ciclo']);?></OPTION>
                                       <?php 
						}
						?>
                                     </select>
                
               <!-- <input name="cb_mostrar" type="submit" class="art-button" onClick="validar($codiGrado)" value="Mostrar" />-->
                         </form>
                        <br>

                        <table width="100%" border="0">
                          <tr class="titulotabla">
                            <td width="5%">N.</td>
                            <td width="25%">Concepto</td>
                            <td width="12%">Estado</td>
                            <td width="14%">Monto (S/.)</td>
                            <td  width="44%">Fecha plazo</td>
                          </tr>
                            <?php for($i=0;$i<$canthistorial;$i++){		

						?>
                         <tr class="<?php if($i % 2){echo 'filapar';}else{ echo 'filaimpar';} ?>" <?php  $fechahoy = date('Y-m-d');
$date = date_create(mssql_result($rhistorial,$i,'fechaPago'));
$fechapagomostrar = date_format($date, 'd-m-Y');
$fechapago = date_format($date, 'Y-m-d');		if (($fechahoy >= $fechapago) and mssql_result($rhistorial,$i,'estaCuota')==0){ echo ' style="background-color:#F66; color:#E9E9E9"';}	 
 ?> >
                            <td><?php
 echo $i +1 ;?></td>
                            <td><?php echo utf8_encode(mssql_result($rhistorial,$i,'nombreDerePago'));
							if(mssql_result($rhistorial,$i,'numeCuota') > 0)
							{
								echo '  cuota ' .mssql_result($rhistorial,$i,'numeCuota'); 
							}?></td>
                            <td><?php  if(mssql_result($rhistorial,$i,'estaCuota')==0){			echo 'Pendiente';
								}else{ echo 'Pagado';}?></td>
                            <td><?php echo utf8_encode(mssql_result($rhistorial,$i,'montoPagoDeuda'));?></td>
                            <td><?php
							
	 echo $fechapagomostrar;
							?></td>
                          </tr>
                          <?php } ?>
                        </table>
                        <p><br>
                          
                        </p>
   

                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html> 
<?php }
else
{ 
  echo "No ha validado su sessión";
}?>