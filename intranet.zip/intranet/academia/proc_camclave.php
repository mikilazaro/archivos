<!-----Para cambiar clave-->
<? 

@session_start();
/*if (isset($_POST['btn_cambiarclave'])) 
{ 
*/	 $codi_usua_intra = $_SESSION['codiUsua'];
$contraActualIngre = $_POST['sle_contra_actual'];
	$nuevaContra = $_POST['sle_contra_nueva'];
	$confirNuevaContra = $_POST['sle_confir_contra_nueva'];
	

	include("includes/conectar_academia.php");
		$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");
	$sql = "Select contraAlum from TAlumnoAcademia where codiAlum = '$codi_usua_intra'";
	$result =  mssql_query($sql);
	//$vector = $bd_sgi->registro($result);
	$vector = mssql_fetch_array($result);
	$contraActual = $vector[0];

	if ($contraActual == $contraActualIngre) 
	{
		//$mensa = "Contraseña actual valida"; 
		if ($nuevaContra == $confirNuevaContra) 
		{
			if (strlen($nuevaContra)<6) { $mensa = '<div  style="background-color:#FFB3B3; width:100%; text-align:center"><br /> * Contraseña muy corta, debe tener como mínimo 6 caracteres.<br /> <br /></div>'; }
			else {
			//$nuevaContra = crc32($nuevaContra);
			//$nuevaContra = $nuevaContra;
			
			$sql = "Update TAlumnoAcademia set contraAlum = '$nuevaContra' where codiAlum = '$codi_usua_intra'";
			$result = mssql_query($sql);
			$sql2 = "SELECT codiPersona FROM TAlumno WHERE codiAlum = '$codi_usua_intra'";
			$result2 = mssql_query($sql2);
			$vector2 =mssql_fetch_array($result2);
			$codiPersoAlum = $vector2[0];
			$sql3 = "SELECT MAX(codiCambioContra) FROM TCambioContraAlumAca";
			$result3 = mssql_query($sql3);
			$vector3 = mssql_fetch_array($result3);
			$ls_codi = $vector3[0];
			$ldt_fechaActu = date("Y/m/d H:i:s");
//			$ldt_fechaActu = '2014-07-30 10:00:05.773';
			//echo $ldt_fechaActu . ' //// ';
			$ls_codiAlumCambio = substr("00000". strval(intval($ls_codi) + 1),-6);
			$sql1 = "INSERT INTO TCambioContraAlumAca(codiCambioContra, codiPersoAlum, contraOri, contraCambio, fechaCambioContra, motiCambioContra, codiPersoCambio) VALUES('$ls_codiAlumCambio', '$codiPersoAlum' , '$contraActual', '$nuevaContra', '$ldt_fechaActu', 'Cambio desde extranet', '$codiPersoAlum')";
			$resultA = mssql_query($sql1);
			//echo date("Y-m-d H:i:s");
			if ($result)
			{$mensa =  '<div  style="background-color:#D7FFE1; width:100%; text-align:center"><br />  * Se cambió la contraseña en forma satisfactoria.<br /><br /> </div>';}
			}
		}
		else { $mensa = '<div  style="background-color:#FFB3B3; width:100%; text-align:center"><br />  * La confirmacion de la nueva contraseña no coincide verifique.<br /><br /> </div>';}
	}
	else { $mensa = '<div  style="background-color:#FFB3B3; width:100%; text-align:center"><br /> * La contraseña actual no es correcta. <br /><br /></div>';}
//}
?>
<?php if(isset($mensa)){ echo $mensa;}else{echo 'Algo salio mal';}
?>