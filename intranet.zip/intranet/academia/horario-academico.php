<? 
session_start();
 include('../piezas/seguridad.php');

if ($_SESSION['validado'] == 'ok') {
$codi_usua_intra	= $_SESSION['codiUsua'];
$usua_intra_cei		= $_SESSION['nombreAlum'] . " " . $_SESSION['apaPaterAlum'] . " " . $_SESSION['apaMaterAlum'];
//-------> inicio	conectar a bd
include("includes/conectar_academia_nuevo.php");
$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");

//-------> fin		conectar a bd

/////--///----------------------
function convertir_fecha($fecha_datetime)
	{
		//$dia = substr($fecha_datetime, 0, 2);
		$dia = substr($fecha_datetime, 4, 2);
		if (strlen(trim($dia)) == 1)
		{
			$dia = '0'.trim($dia);
			//$mes = strtoupper(substr($fecha_datetime, 2, 3));
			$mes = strtoupper(substr($fecha_datetime, 0, 3));
			$anio = substr($fecha_datetime, 6, 4);
		}
		else
		{
			//$mes = strtoupper(substr($fecha_datetime, 3, 3));
			$mes = strtoupper(substr($fecha_datetime, 0, 3));
			$anio = substr($fecha_datetime, 7, 4);
		}
		switch($mes)
		{
			case "MAR":
			$fecha = $dia."/03/".$anio;
			break;
			case "ABR":
			$fecha = $dia."/04/".$anio;
			break;
			case "MAY":
			$fecha = $dia."/05/".$anio;
			break;
			case "JUN":
			$fecha = $dia."/06/".$anio;
			break;
			case "JUL":
			$fecha = $dia."/07/".$anio;
			break;
			case "AGO":
			$fecha = $dia."/08/".$anio;
			break;
			case "SEP":
			$fecha = $dia."/09/".$anio;
			break;
			case "OCT":
			$fecha = $dia."/10/".$anio;
			break;
			case "NOV":
			$fecha = $dia."/11/".$anio;
			break;
			case "DIC":
			$fecha = $dia."/12/".$anio;
			break;
		}
		return $fecha;
	}
	
		$nombreSema = array();
		$fechaIniSema = array();
		$fechaFinalSema = array();
		$obserCrono = array();
		
		$horaClases = array();
		$HoraIni = array();
		$HoraFina = array();
		
		$HoraIniSab = array();
		$HoraFinaSab = array();
		
		
		if(isset($_POST['ddlb_perio_lecti'])) 
			{
				$codigos = $_POST['ddlb_perio_lecti'];
				$coditiposema = $_POST['ddlb_tipo_eva'];
				
				if ($codigos == '0' || $coditiposema == '0') 
				{ 
					if ($codigos == '0') {
					$mensaUsua = "Seleccione el ciclo"; 
					}
					if ($coditiposema == '0') {
					$mensaUsua = "Seleccione el tipo de semana"; 
					}
				}
				else
				{
					$codiAnio = substr($codigos,0,4);
					$numeTempo = substr($codigos,4,1);
					$codiTurno = substr($codigos,5,3);
					$codiCicloAca = substr($codigos,8,8);
					$codiAreaCanal = substr($codigos,16,4);
					
					$sqlcodiPrograAca = "select codiPrograAca from TProgramaAcademia where codiAnio = '$codiAnio' and numeTempo = '$numeTempo' and codiCicloAca = '$codiCicloAca' and codiTurno ='$codiTurno' and codiAreaCanal = '$codiAreaCanal';";
					$sqlResulCodiprogra = mssql_query($sqlcodiPrograAca);
					$registroCodiProgra = mssql_fetch_array($sqlResulCodiprogra);
					$codiprograAca = $registroCodiProgra["codiPrograAca"];
					
			 
					$sqlNomCicloAca = "select nombreCicloAca from TCicloPreparacionAcademia where codiCicloAca = '$codiCicloAca'";
					$sqlResulNomCicloAca = mssql_query($sqlNomCicloAca);
					$regisNomCicloAca = mssql_fetch_array($sqlResulNomCicloAca);
					$nombreCicloAca = $regisNomCicloAca["nombreCicloAca"];

					$sqlNomAnio = "select nombreAnio from tanio where codiAnio = '$codiAnio'";
					$sqlResulNomAnio = mssql_query($sqlNomAnio);
					$sqlRegisNomAnio = mssql_fetch_array($sqlResulNomAnio);
					$nombreAnio = $sqlRegisNomAnio["nombreAnio"];
					
					$sqlNomaArea = "select nombreAreaCanal from TAreaCanal where codiAreaCanal = '$codiAreaCanal'";
					$sqlResulNomArea = mssql_query($sqlNomaArea);
					$sqlRegisNomArea = mssql_fetch_array($sqlResulNomArea);
					$nombreArea = $sqlRegisNomArea["nombreAreaCanal"];
					
					$sqlNomTurno = "select nombreTurno from TTurno where codiTurno = '$codiTurno'";
					$sqlResulNomTurno = mssql_query($sqlNomTurno);
					$sqlRegisNomTurno = mssql_fetch_array($sqlResulNomTurno);
					$nombreTurno = $sqlRegisNomTurno["nombreTurno"];
							
					$nombreProgra = strtoupper($nombreCicloAca . " " . $nombreAnio . " (" . $nombreArea . ") TURNO " . $nombreTurno );											
					//echo 'Nombre: ' .  $nombreProgra;
					//Fin nombre programa
					
					$sqlNombreEva = "select nombretiposema from ttiposemanaacademia where coditiposema = '$coditiposema'";
					$sqlResul = mssql_query($sqlNombreEva);
					$regis = mssql_fetch_array($sqlResul);
					$nombresema = $regis["nombretiposema"];
					$tituEva = $nombreProgra . ' - SEMANA ' . strtoupper($nombresema);
					$mensaUsua = ''; 
					
					$sqlcodiSeccion = "select codiSeccionA from TMatriculaAcademia where codialum = '$codi_usua_intra' and codiPrograAca = '$codiprograAca' order by codiSeccionA Desc";
					$sqlResul = mssql_query($sqlcodiSeccion);
					$regis = mssql_fetch_array($sqlResul);
					$codiseccion = $regis["codiSeccionA"];
					//echo $codiseccion . ' ' . $codi_usua_intra . ' ' .$codiprograAca;
					
				}
				
			}
			
				$sqlHoraClases = "SELECT horaIni, horaFina FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D001' ORDER BY horaIni;";
				$resultHoraClases = mssql_query($sqlHoraClases);
				$i = 0;
				if (mssql_num_rows($resultHoraClases))
				{
					while ($rowHoraClases=mssql_fetch_array($resultHoraClases)) 
					{
						$i = $i + 1;
						$HoraIni[$i] = convertir_fecha($rowHoraClases['horaIni']);
						$HoraFina[$i] = convertir_fecha($rowHoraClases['horaFina']);
						
						$strinHoraIni = explode("1900", $rowHoraClases['horaIni'] );
						
						$HoraIni1 = explode(":", $strinHoraIni[1] );
							$HoraHoraIni1[$i] = $HoraIni1[0];
							$HoraMinIni1[$i] = $HoraIni1[1];
							
						$strinHoraFina = explode("1900", $rowHoraClases['horaFina'] );
							
						$HoraFina1	= explode(":", $strinHoraFina[1] );
							$HoraHoraFina1[$i] = $HoraFina1[0];
							$HoraMinFina1[$i] = $HoraFina1[1]; 
						
					}
				} 	
				//Sabado
				$sqlHoraClasesSab = "SELECT horaIni, horaFina FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D006' ORDER BY horaIni;";
				$resultHoraClasesSab = mssql_query($sqlHoraClasesSab);
				$i=0;
				$cantresultHoraClasesSab = mssql_num_rows($resultHoraClasesSab);
				if (mssql_num_rows($resultHoraClasesSab))
				{
					while ($rowHoraClasesSab=mssql_fetch_array($resultHoraClasesSab)) 
					{
						$i = $i + 1;
						$HoraIniSab[$i] = convertir_fecha($rowHoraClasesSab['horaIni']);
						$HoraFinaSab[$i] = convertir_fecha($rowHoraClasesSab['horaFina']);
						
						$strinHoraIniSab = explode("1900", $rowHoraClasesSab['horaIni'] );
						
						$HoraIni1Sab = explode(":", $strinHoraIniSab[1] );
							$HoraHoraIni1Sab[$i] = $HoraIni1Sab[0];
							$HoraMinIni1Sab[$i] = $HoraIni1Sab[1];
							
						$strinHoraFinaSab = explode("1900", $rowHoraClasesSab['horaFina'] );
							
						$HoraFina1Sab = explode(":", $strinHoraFinaSab[1] );
							$HoraHoraFina1Sab[$i] = $HoraFina1Sab[0];
							$HoraMinFina1Sab[$i] = $HoraFina1Sab[1]; 
						
					}
				} 
				//Domingo
				$sqlHoraClasesDom = "SELECT horaIni, horaFina FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D007' ORDER BY horaIni;";
				$resultHoraClasesDom = mssql_query($sqlHoraClasesDom);
				$i=0;
				if (mssql_num_rows($resultHoraClasesDom))
				{
					while ($rowHoraClasesDom=mssql_fetch_array($resultHoraClasesDom)) 
					{
						$i = $i + 1;
						$HoraIniDom[$i] = convertir_fecha($rowHoraClasesDom['horaIni']);
						$HoraFinaDom[$i] = convertir_fecha($rowHoraClasesDom['horaFina']);
						
						$strinHoraIniDom = explode("1900", $rowHoraClasesDom['horaIni'] );
						
						$HoraIni1Dom = explode(":", $strinHoraIniDom[1] );
							$HoraHoraIni1Dom[$i] = $HoraIni1Dom[0];
							$HoraMinIni1Dom[$i] = $HoraIni1Dom[1];
							
						$strinHoraFinaDom = explode("1900", $rowHoraClasesDom['horaFina'] );
							
						$HoraFina1Dom = explode(":", $strinHoraFinaDom[1] );
							$HoraHoraFina1Dom[$i] = $HoraFina1Dom[0];
							$HoraMinFina1Dom[$i] = $HoraFina1Dom[1]; 
						
					}
				} 

				$i=0;
				$queryCursoLunes = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D001' ORDER BY horaIni;";
				$resultCursoLunes = mssql_query($queryCursoLunes);
				
				if (mssql_num_rows($resultCursoLunes)) {
					while ($rowDetaCursoLunes=mssql_fetch_array($resultCursoLunes)) 
					{
						$i = $i + 1;
						$nombreCursoLunes[$i] = $rowDetaCursoLunes['descripClase'];
					}
				} 
				$i=0;
				$queryCursoMartes = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D002' ORDER BY horaIni;";
				$resultCursoMartes = mssql_query($queryCursoMartes);
				
				if (mssql_num_rows($resultCursoMartes)) {
					while ($rowDetaCursoMartes=mssql_fetch_array($resultCursoMartes)) 
					{
						$i = $i + 1;
						$nombreCursoMartes[$i] = $rowDetaCursoMartes['descripClase'];
					}
				} 
				$i=0;
				$queryCursoMiercoles = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D003' ORDER BY horaIni;";
				$resultCursoMiercoles = mssql_query($queryCursoMiercoles);
				
				if (mssql_num_rows($resultCursoMiercoles)) {
					while ($rowDetaCursoMiercoles=mssql_fetch_array($resultCursoMiercoles)) 
					{
						$i = $i + 1;
						$nombreCursoMiercoles[$i] = $rowDetaCursoMiercoles['descripClase'];
					}
				} 
				$i=0;
				$queryCursoJue = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D004' ORDER BY horaIni;";
				$resultCursoJue = mssql_query($queryCursoJue);
				
				if (mssql_num_rows($resultCursoJue)) {
					while ($rowDetaCursoJue=mssql_fetch_array($resultCursoJue)) 
					{
						$i = $i + 1;
						$nombreCursoJue[$i] = $rowDetaCursoJue['descripClase'];
					
					}
				} 
				$i=0;
				$queryCursoVie = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D005' ORDER BY horaIni;";
				$resultCursoVie = mssql_query($queryCursoVie);
				
				if (mssql_num_rows($resultCursoVie)) {
					while ($rowDetaCursoVie=mssql_fetch_array($resultCursoVie)) 
					{
						$i = $i + 1;
						$nombreCursoVie[$i] = $rowDetaCursoVie['descripClase'];
					}
				} 
				$i=0;
				
				$queryCursoSab = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D006' ORDER BY horaIni;";
				$resultCursoSab = mssql_query($queryCursoSab);
				
				if (mssql_num_rows($resultCursoSab)) {
					while ($rowDetaCursoSab=mssql_fetch_array($resultCursoSab)) 
					{
						$i = $i + 1;
						$nombreCursoSab[$i] = $rowDetaCursoSab['descripClase'];
						
					}
				}
				$i=0;
				$queryCursoDom = "SELECT descripClase FROM THorarioClaseAcademia where codiSeccionA = '$codiseccion' and codiTipoSema = '$coditiposema' and codiDia = 'D007' ORDER BY horaIni;";
				$resultCursoDom = mssql_query($queryCursoDom);
				
				if (mssql_num_rows($resultCursoDom)) {
					while ($rowDetaCursoDom=mssql_fetch_array($resultCursoDom)) 
					{
						$i = $i + 1;
						$nombreCursoDom[$i] = $rowDetaCursoDom['descripClase'];
					}
				}
			
?>

<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Horario académico</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
  <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
     <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>
  <script>
			function imprimir(){
				document.getElementById('oculto').style.display = 'block';
		  var objeto=document.getElementById('imprimir');
		 var ventana=window.open('','_blank');  
		  ventana.document.write(objeto.innerHTML);  	  ventana.document.close();  
		  ventana.print(); 
		  				document.getElementById('oculto').style.display = 'none';
		  ventana.close(); 		  
		}
	</script>
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">HORARIO ACADÉMICO</span></h2>
                        </div>
                                
                      <div class="art-postcontent art-postcontent-0 clearfix">
                   
                                      
                     <form action="horario-academico.php" method="post" name="formu_opcio">    <table width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <td width="80">
        <?php 
		
			$sqlCicloEstu = "select	tprogramaacademia.codianio + cast(tprogramaacademia.numetempo as char(1)) + tprogramaacademia.coditurno + tprogramaacademia.codicicloaca + tprogramaacademia.codiareacanal as codi, upper(tciclopreparacionacademia.nombreCicloAca + ' ' + tanio.nombreAnio + '-' + cast(tprogramaacademia.numetempo as char(1)) + ' (' + tareacanal.nombreAreaCanal + ')' + ' TURNO ' + tturno.nombreTurno) as nombreciclo from tmatriculaacademia inner join tprogramaacademia on	tmatriculaacademia.codiprograaca =  tprogramaacademia.codiprograaca inner join tanio on tprogramaacademia.codianio = tanio.codianio inner join tciclopreparacionacademia on tprogramaacademia.codicicloaca = tciclopreparacionacademia.codicicloaca inner join tturno on tprogramaacademia.coditurno = tturno.coditurno inner join tareacanal on tprogramaacademia.codiareacanal = tareacanal.codiareacanal where tmatriculaacademia.codialum = '$codi_usua_intra' order by tmatriculaacademia.codimatriaca desc;";

					$resulConsul = mssql_query($sqlCicloEstu); 
	$cantidadciclo=mssql_num_rows($resulConsul);

?> <strong> Selecciona ciclo preparación :</strong>
<select name="ddlb_perio_lecti" id="ddlb_perio_lecti" onChange="this.form.submit()">
            <option value='0'>-- Seleccione --</option>
                                       <?php for($i=0;$i<$cantidadciclo;$i++){		
						?>
                                       <OPTION value="<?php echo mssql_result($resulConsul,$i,'codi');?>" <?php if ( mssql_result($resulConsul,$i,'codi') == $codigos ) { echo 'selected';}?>   ><?php echo utf8_encode(mssql_result($resulConsul,$i,'nombreciclo'));?></OPTION>
                                       <?php 
						}
						?>
                                     </select>
         </td>
    <tr>
                      <td>
                      <?php

	
	$codiAnio = substr($codigos,0,4);
	$numeTempo = substr($codigos,4,1);
	$codiTurno = substr($codigos,5,3);
	$codiCicloAca = substr($codigos,8,8);
	$codiAreaCanal = substr($codigos,16,4);
	
	$consulta=mssql_query("SELECT distinct TDetalleSemanaProgramaAcademia.codiTipoSema, ttiposemanaacademia.nombreTipoSema from TDetalleSemanaProgramaAcademia inner join ttiposemanaacademia on TDetalleSemanaProgramaAcademia.coditiposema = ttiposemanaacademia.coditiposema where codiAnio = '".$codiAnio."'  and numeTempo = '".$numeTempo."' and codiTurno = '".$codiTurno."' and codiCicloAca = '".$codiCicloAca."' order by TDetalleSemanaProgramaAcademia.codiTipoSema;") or die(mssql_error());	
		$cantidadtipo=mssql_num_rows($consulta);
	

?>
       <strong> Selecciona tipo de semana : &nbsp;&nbsp;</strong>
 <select  name="ddlb_tipo_eva" id="ddlb_tipo_eva" onChange="this.form.submit()">
            <option value='0'>-- Seleccione --</option>
                                       <?php for($i=0;$i<$cantidadtipo;$i++){		
						?>
                                       <OPTION value="<?php echo mssql_result($consulta,$i,'codiTipoSema');?>" <?php if ( mssql_result($consulta,$i,'codiTipoSema') == $coditiposema ) { echo 'selected';}?>   ><?php echo utf8_encode(mssql_result($consulta,$i,'nombreTipoSema'));?></OPTION>
                                       <?php 
						}
						?>
                                     </select>                
                    </td>
                      </table>	
                       </form>


  <div id="imprimir" style=" border-style: ridge; overflow-y:scroll; overflow-x:scroll;  width:100%">
     <div id="oculto" style="display:none;  font-size:11px" >
             <div style="float:left;text-align:left; width:60%">
<img src="../estilos/images/logo_academia.png" width="40" height="42"> <img src="../estilos/images/logo_academia_solotexto.png" width="101" height="37"></div>
             <div style="float:left; text-align:right; width:30%">
             <?php echo date('d-m-Y h:i:s A') ?>             </div>  
   <br>
    <br><br>
<br>




   <table border="1"  width="99%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="" style="text-align:center" ><strong>MI HORARIO ACADÉMICO</strong></td>
    </tr>
  </table><br>

  <strong>Mis datos:</strong> <?php echo utf8_encode( $_SESSION["nombreAlum"].' '.$_SESSION["apellidoAlum"]); ?>
 <br>
 <strong>Código:</strong> <?php echo $_SESSION["User"]; ?>
 </div> 
  
<table width="99%" border="1" cellpadding="0" cellspacing="0" style="font-size:12px" >
  <col width="80" span="5">
  <tr>
    <td colspan="10"  style="text-align:center"><? echo $mensaUsua; ?><br>      
  <strong>  <?php echo utf8_encode($tituEva);  ?></strong></td>
  </tr>
  <tr class="titulotabla">
    <td width="49"><strong>HORA</strong></td>
    <td width="221"><strong>LUNES</strong></td>
    <td width="254"><strong>MARTES</strong></td>
    <td width="266"><strong>MIERCOLES</strong></td>
    <td width="239"><strong>JUEVES</strong></td>
    <td width="155"><strong>VIERNES</strong></td>
    
    </tr>
       <?php for($i=1;$i<=count($HoraIni);$i++){		
						?>
  <tr class="<?php if($i % 2){echo 'filapar';}else{ echo 'filaimpar';} ?>" >
    <td><?php 
							
							//echo "<div id=\"fila_sema_nombre\">" . $codiseccion . " - ". $coditiposema . "</div>";
							/*for ($i = 1; $i <= count($HoraIni) ; $i++)
							{*/	
								if ($HoraIni[$i] == '')
								{ $HoraIni[$i] = " - "; }
								//echo "<div id=\"fila_sema_nombre\">" . $HoraIni[$i] . " - " . $HoraFina[$i] . "</div>";
								echo  $HoraHoraIni1[$i] . ":" . $HoraMinIni1[$i] . " - " . $HoraHoraFina1[$i] . ":" . $HoraMinFina1[$i] . "<br><br>
";
						//	}
						?></td>
    <td <?php if (strtoupper(substr($nombreCursoLunes[$i], 0, 2)) == "RE"){ echo 'colspan="5" style="text-align:center"';}?>> <?php 
							/*for ($i = 1; $i <= count($nombreCursoLunes) ; $i++)
							{*/	
								if ($nombreCursoLunes[$i] == '')
								{ $nombreCursoLunes[$i] = " - "; }
								$codiCurso = strtoupper(substr($nombreCursoLunes[$i], 0, 2));
								$nuevoCodiCurso = strtoupper(substr($nombreCursoLunes[$i], 2, 2));
								switch ($codiCurso)
								{
									
									case "CA":
										if ($nombreCursoLunes[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nuevoCodiCurso'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "<strong>RECESO</strong>";
										break;
									 default:
										 $sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoLunes[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"];
									 
								}
								echo  "<br>".utf8_encode($nombreCurso)."<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoLunes[$i] . "</div>";
								
								
						//	}
						?><?php if (strtoupper(substr($nombreCursoLunes[$i], 0, 2)) != "RE"){ echo '</td>
    <td>'; ?> <?php 
						    $nuevoCodiCurso='';
							$nombreCurso='';
						/*	for ($i = 1; $i <= count($nombreCursoMartes) ; $i++)
							{*/	
								if ($nombreCursoMartes[$i] == '')
								{ $nombreCursoMartes[$i] = " - "; }
								$codiCurso = strtoupper(substr($nombreCursoMartes[$i], 0, 2));
								$nuevoCodiCurso = strtoupper(substr($nombreCursoMartes[$i], 2, 2));
								switch ($codiCurso)
								{
							
									case "CA":
										if ($nombreCursoMartes[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nuevoCodiCurso'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "";
										break;
										
									 default:
									 	$sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoMartes[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"];
								}
								echo  "<br>".utf8_encode($nombreCurso)."<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoMartes[$i] . "</div>";
							//}
						?><?php if (strtoupper(substr($nombreCursoLunes[$i], 0, 2)) != "RE"){ echo '</td>
    <td>';}?><?php
						    $nuevoCodiCurso='';
							$nombreCurso='';
						/*	for ($i = 1; $i <= count($nombreCursoMiercoles) ; $i++)
							{*/	
								if ($nombreCursoMiercoles[$i] == '')
								{ $nombreCursoMiercoles[$i] = " - "; }
								$codiCurso = strtoupper(substr($nombreCursoMiercoles[$i], 0, 2));
								$nuevoCodiCurso = strtoupper(substr($nombreCursoMiercoles[$i], 2, 2));
								switch ($codiCurso)
								{
							
									case "CA":
										if ($nombreCursoMiercoles[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nuevoCodiCurso'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "";
										break;
									 default:
										$sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoMiercoles[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"]; 	
										
										
								}
								echo  "<br>".utf8_encode($nombreCurso)."<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoMiercoles[$i] . "</div>";
							//}
						?><?php } if (strtoupper(substr($nombreCursoLunes[$i], 0, 2)) != "RE"){ echo '</td>
    <td>';?><?php
							$nuevoCodiCurso='';
							$nombreCurso='';
							/*for ($i = 1; $i <= count($nombreCursoJue) ; $i++)
							{*/	
								if ($nombreCursoJue[$i] == '')
								{ $nombreCursoJue[$i] = " - "; }
								$codiCurso = strtoupper(substr($nombreCursoJue[$i], 0, 2));
								$nuevoCodiCurso = strtoupper(substr($nombreCursoJue[$i], 2, 2));
								switch ($codiCurso)
								{
									
								
									case "CA":
										if ($nombreCursoJue[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nuevoCodiCurso'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "";
										break;
										default:
										$sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoJue[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"];
								}
								echo "<br>".utf8_encode($nombreCurso)."<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoJue[$i] . "</div>";
							//}
						?><?php } if (strtoupper(substr($nombreCursoLunes[$i], 0, 2)) != "RE"){ echo '</td>
    <td>';?><?php 
						  	$nuevoCodiCurso='';
							$nombreCurso='';
							/*for ($i = 1; $i <= count($nombreCursoVie) ; $i++)
							{*/	
								if ($nombreCursoVie[$i] == '')
								{ $nombreCursoVie[$i] = " - "; }
								$codiCurso = strtoupper(substr($nombreCursoVie[$i], 0, 2));
								$nuevoCodiCurso = strtoupper(substr($nombreCursoVie[$i], 2, 2));
								switch ($codiCurso)
								{
							
									case "CA":
										if ($nombreCursoVie[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nuevoCodiCurso'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "";
										break;
									default:
										$sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoVie[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"];
								}
								echo  "<br>".utf8_encode($nombreCurso)."<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoVie[$i] . "</div>";
						//	}
						} ?></td>
  </tr>
  <?php } ?>
</table>

<table width="99%" border="1" style="font-size:12px" >
  <tr class="titulotabla">
    <td width="16%"><strong>HORA</strong></td>
    <td width="31%"><strong>SABADO</strong></td>
    <td width="18%"><strong>HORA</strong></td>
    <td width="35%"><strong>DOMINGO</strong></td>
  </tr>
  
 <?php 

    for ($i = 1; $i <= count($HoraIniSab) ; $i++)
                                { ?>
  <tr class="<?php if($i % 2){echo 'filapar';}else{ echo 'filaimpar';} ?>" >
    <td><?php 
                                
                                //echo "<div id=\"fila_sema_nombre\">" . $codiseccion . " - ". $coditiposema . "</div>";
                             /*   for ($i = 1; $i <= count($HoraIniSab) ; $i++)
                                {*/	
                                    if ($HoraIniSab[$i] == '')
                                    { $HoraIniSab[$i] = " - "; }
                                    //echo "<div id=\"fila_sema_nombre\">" . $HoraIni[$i] . " - " . $HoraFina[$i] . "</div>";
                                    echo "<br>" . $HoraHoraIni1Sab[$i] . ":" . $HoraMinIni1Sab[$i] . " - " . $HoraHoraFina1Sab[$i] . " : " . $HoraMinFina1Sab[$i] . "<br><br>";
                               // }
                            ?></td>
    <td><?php 
                          /*      for ($i = 1; $i <= count($nombreCursoSab) ; $i++)
                                {*/	
                                    if ($nombreCursoSab[$i] == '')
                                    { $nombreCursoSab[$i] = " - "; }

                                    $codiCurso = strtoupper(substr($nombreCursoSab[$i], 0, 2));
									
								switch ($codiCurso)
								{
									
										
									case "CA":
										if ($nombreCursoSab[$i] == "CA00"){
											$nombreCursoS = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nombreCursoSab[$i]'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCursoS = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCursoS = "||| RECESO |||";
										break;
									 default:
									 $sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoSab[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCursoS = $regis["nombreTipoEva"];
										
								}
								echo "<br>" . utf8_encode($nombreCursoS ). "<br>
<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoSab[$i] . "</div>";
                              //  }
                            ?></td>
    <td><?php 
                                
                                //echo "<div id=\"fila_sema_nombre\">" . $codiseccion . " - ". $coditiposema . "</div>";
                                for ($i = 1; $i <= count($HoraIniDom) ; $i++)
                                {	
                                    if ($HoraIniDom[$i] == '')
                                    { $HoraIniDom[$i] = " - "; }
                                    //echo "<div id=\"fila_sema_nombre\">" . $HoraIni[$i] . " - " . $HoraFina[$i] . "</div>";
                                    echo "<br>" . $HoraHoraIni1Dom[$i] . ":" . $HoraMinIni1Dom[$i] . " - " . $HoraHoraFina1Dom[$i] . " : " . $HoraMinFina1Dom[$i] . "<br><br>";
                                }
                            ?></td>
    <td><?php 
                                for ($i = 1; $i <= count($nombreCursoDom) ; $i++)
                                {	
                                    if ($nombreCursoDom[$i] == '')
                                    { $nombreCursoDom[$i] = " - "; }
                                    $codiCurso = strtoupper(substr($nombreCursoDom[$i], 0, 2));
								switch ($codiCurso)
								{
							
									case "CA":
										if ($nombreCursoDom[$i] == "CA00"){
											$nombreCurso = "";
										}
										else{
											$sqlCurso = "select nombreCursoAca from TCursoAcademia where codiCursoAca = '$nombreCursoDom[$i]'";
											$sqlResul = mssql_query($sqlCurso);
											$regis = mssql_fetch_array($sqlResul);
											$nombreCurso = $regis["nombreCursoAca"];
										}
										break;
									case "RE":
										$nombreCurso = "||| RECESO |||";
										break;
									 default:
									 $sqlTipoEva = "select nombreTipoEva from TTipoEvaluacionSPU where codiTipoEva = '$nombreCursoDom[$i]'";
										$sqlResul = mssql_query($sqlTipoEva);
										$regis = mssql_fetch_array($sqlResul);
										$nombreCurso = $regis["nombreTipoEva"];
								}
								echo"<br>". utf8_encode($nombreCurso) . "<br>";
								//echo "<div id=\"fila_sema_fecha_ini\">" . $nombreCursoDom[$i] . "</div>";
                                }
                            ?></td>
  </tr>
  <?php } ?>
</table>



              </div> <div align="right"><input name="cb_impri" type="button" class="art-button"   onClick="imprimir();" value="Imprimir"/></div>
                       
                       
                      </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<? 
}
else
{ 
  echo "No ha validado su sessión";
}
?>