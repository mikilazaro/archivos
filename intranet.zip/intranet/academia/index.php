<? 
session_start();
 include('../piezas/seguridad.php');
if ($_SESSION['validado'] == 'ok') {
$codi_usua_intra = $_SESSION['codiUsua'];
$usua_intra_cei = $_SESSION['nombreAlum'] . " " . $_SESSION['apaPaterAlum'] . " " . $_SESSION['apaMaterAlum'];


//-------> inicio	conectar a bd
include("includes/conectar_academia_nuevo.php");
$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");
//-------> fin		conectar a bd

	

		$nombreSema = array();
		$fechaIniSema = array();
		$fechaFinalSema = array();
		$obserCrono = array();
		
		if(isset($_POST['ddlb_perio_lecti'])) 
			{
				$codigos = $_POST['ddlb_perio_lecti'];
			
				if ($codigos == '0')
				{ 
					$mensaUsua = "Seleccione el ciclo";
				}
				else
				{
					$codiAnio = substr($codigos,0,4);
					$numeTempo = substr($codigos,4,1);
					$codiTurno = substr($codigos,5,3);
					$codiCicloAca = substr($codigos,8,8);
					$codiAreaCanal = substr($codigos,16,4);
					
					$sqlNombreProgra = "select top 1 dbo.f_sia_obteNombrePrograAca ('$codiAnio',$numeTempo,'$codiTurno','$codiCicloAca','$codiAreaCanal',1) as nombreprogra from tprogramaacademia;";
					$sqlResul = mssql_query($sqlNombreProgra);
					$regis = mssql_fetch_array($sqlResul);
					$nombreProgra = $regis["nombreprogra"];
					$mensaUsua = ''; 
				}
				
			}
			else 
			{

				$sqlUltiProgra = "select tprogramaacademia.codianio, tprogramaacademia.numetempo, tprogramaacademia.coditurno, tprogramaacademia.codicicloaca, tprogramaacademia.codiareacanal from tmatriculaacademia inner join tprogramaacademia on tmatriculaacademia.codiprograaca = tprogramaacademia.codiprograaca where tmatriculaacademia.codialum = '$codi_usua_intra' order by tmatriculaacademia.codimatriaca desc;";
				$sqlResul = mssql_query ($sqlUltiProgra);
				$regisProgra = mssql_fetch_array($sqlResul);
				
				$codiAnio = $regisProgra['codianio'];
				$numeTempo = $regisProgra['numetempo'];
				$codiTurno = $regisProgra['coditurno'];
				$codiCicloAca = $regisProgra['codicicloaca'];
				$codiAreaCanal = $regisProgra['codiareacanal'];
				$codigos = $codiAnio.$numeTempo.$codiTurno.$codiCicloAca.$codiAreaCanal;
				
								$sqlNombreProgra = "select top 1 dbo.f_sia_obteNombrePrograAca ('$codiAnio',$numeTempo,'$codiTurno','$codiCicloAca','$codiAreaCanal',1) as nombreprogra from tprogramaacademia;";
				$sqlResul = mssql_query($sqlNombreProgra);
				$regis = mssql_fetch_array($sqlResul);
				$nombreProgra = $regis["nombreprogra"];
				$nombreProgra = $nombreProgra;
				$mensaUsua = '';
			}	

	//****** Ejecuta por defecto------------------------------------------------------ ///

			
				$queryDetaSema = "select nombreCrono, fechainisema, fechafinalsema, obsercrono from	sia_mga_v_r_cronoclaseaca 
where codiAnio = '".$codiAnio."' and numeTempo = '$numeTempo' and codiTurno = '".$codiTurno."' and codicicloaca = '".$codiCicloAca."'";
				$resultDetaSema = mssql_query($queryDetaSema);
				$cantresultdetasema = mssql_num_rows($resultDetaSema);
				
				if (mssql_num_rows($resultDetaSema)) {
					while ($rowDetaSema=mssql_fetch_array($resultDetaSema)) {
						$i = $i + 1;
						$nombreSema[$i] = $rowDetaSema['nombreCrono'];
						$fechaIniSema[$i] = $rowDetaSema['fechainisema'];
					$fechaFinalSema[$i] = ($rowDetaSema['fechafinalsema']);
						$obserCrono[$i] = $rowDetaSema['obsercrono'];
						
					}
				}
				
				
?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>Cronograma Semanal</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
    <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
     <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>
 <script>
			function imprimir(){
				document.getElementById('oculto').style.display = 'block';
		  var objeto=document.getElementById('imprimir');
		 var ventana=window.open('','_blank');  
		  ventana.document.write(objeto.innerHTML);  	  ventana.document.close();  
		  ventana.print(); 
		  				document.getElementById('oculto').style.display = 'none';
		  ventana.close(); 		  
		}
	</script>
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">CRONOGRAMA SEMANAL</span></h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix">
                  
                  
				   <form action="cronograma-semanal.php" method="post" name="formu_opcio">    <table width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <td width="80">
	 <strong> Selecciona ciclo preparación : </strong>
                         <?php 
						$db_link = mssql_select_db($db,$link) or die ("Nombre de BD no existe");
					 						
				$sqlCicloEstu = mssql_query("select	tprogramaacademia.codianio + cast(tprogramaacademia.numetempo as char(1)) + tprogramaacademia.coditurno + tprogramaacademia.codicicloaca + tprogramaacademia.codiareacanal as codi, upper(tciclopreparacionacademia.nombreCicloAca + ' ' + tanio.nombreAnio + '-' + cast(tprogramaacademia.numetempo as char(1)) + ' (' + tareacanal.nombreAreaCanal + ')' + ' TURNO ' + tturno.nombreTurno) as nombreciclo from tmatriculaacademia inner join tprogramaacademia on	tmatriculaacademia.codiprograaca =  tprogramaacademia.codiprograaca inner join tanio on tprogramaacademia.codianio = tanio.codianio inner join tciclopreparacionacademia on tprogramaacademia.codicicloaca = tciclopreparacionacademia.codicicloaca inner join tturno on tprogramaacademia.coditurno = tturno.coditurno inner join tareacanal on tprogramaacademia.codiareacanal = tareacanal.codiareacanal where tmatriculaacademia.codialum = '$codi_usua_intra' order by tmatriculaacademia.codimatriaca desc;");
				$cantidadciclo=mssql_num_rows($sqlCicloEstu);
				
				
//A0001124
//A0009013
//$codi_usua_intra
//'$usua_intra_cei'
					
						?>    <select   name="ddlb_perio_lecti" id="ddlb_perio_lecti" onchange="this.form.submit()" >
            <option value='0'>-- Seleccione --</option>
                                       <?php for($i=0;$i<$cantidadciclo;$i++){		
						?>
                                       <OPTION value="<?php echo mssql_result($sqlCicloEstu,$i,'codi');?>" <?php if ( mssql_result($sqlCicloEstu,$i,'codi') == $codigos ) { echo 'selected';}?>   ><?php echo utf8_encode(mssql_result($sqlCicloEstu,$i,'nombreciclo'));?></OPTION>
                                       <?php 
						}
						?>
                                     </select></td>
   
                       <tr>
                       
                         </table>	
                       </form> 
                       

  <div id="imprimir" style=" overflow-y:scroll; overflow-x:scroll;  width:100%">
  
             <div id="oculto" style="display:none;  font-size:11px" >
             <div style="float:left;text-align:left; width:60%">
<img src="../estilos/images/logo_academia.png" width="40" height="42"> <img src="../estilos/images/logo_academia_solotexto.png" width="101" height="37"></div>
             <div style="float:left; text-align:right; width:30%">
             <?php echo date('d-m-Y h:i:s A') ?>             </div>  
   <br>
    <br><br>
<br>

</div>

                <table width="99%" cellpadding="0" cellspacing="0" border="1">
                      <col  span="4">
                      <tr>
                        <td colspan="4" style="text-align:center"><strong><?php echo utf8_encode($nombreProgra); ?></strong></td>
                      </tr>
                      <tr class="titulotabla">
                        <td width="20%"  ><strong>DESCRIPCION</strong></td>
                        <td width="26%"  ><strong>FECHA INICIO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                        <td width="22%" ><strong>FECHA FINALIZACIÓN</strong></td>
                        <td width="32%"  ><strong>OBSERVACIÓN</strong></td>
                      </tr>
                    <?php for($i=1;$i<=$cantresultdetasema;$i++){		
						?>
                      <tr class="<?php if($i % 2){echo 'filapar';}else{ echo 'filaimpar';} ?>">
                        <td><?php echo utf8_encode($nombreSema[$i]); ?></td>
                        <td><?php $inicio_date = date_create($fechaIniSema[$i]);
        $returninicio = date_format($inicio_date, "d-m-Y");
								echo   $returninicio ?></td>
                        <td><?php $fin_date = date_create($fechaFinalSema[$i]);
        $returnfin = date_format($fin_date, "d-m-Y");
								echo   $returnfin; ?></td>
                        <td><?php echo  utf8_encode($obserCrono[$i]);?></td>
                      </tr>
                      <?php } ?>
                    </table>
                    <br>
                   
                <br>


</div> <div align="right"><input name="cb_impri" type="button" class="art-button"   onClick="imprimir();" value="Imprimir"/></div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<? 
}
else
{ 
  echo "No ha validado su sessión";
}
?>