<?
 session_start(); 
 include('../piezas/seguridad.php');
if ($_SESSION['validado'] == 'ok') {
 
$codi_usua_intra = $_SESSION['codiUsua'];
$usua_intra_cei = $_SESSION['nombrePerso'] . " " . $_SESSION['apaPaterPerso'] . " " . $_SESSION['apaMaterPerso'];

?>
<!DOCTYPE html>
<html dir="ltr" lang="es-PE" xml:lang="es-PE"><head>
    <meta charset="utf-8">
    <title>BOLETA BIMESTRAL DE NOTAS</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
    <link rel="stylesheet" href="../estilos/style.css" media="screen">
    <link href="../includes/intra_bole_notas_bimes.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../estilos/style.responsive.css" media="all">
     <link href="../estilos/bootstrap.css" rel="stylesheet">
    <link rel="icon" href="../estilos/images/<?php if(isset($favicon)){ echo $favicon;}?>" type="image/png" />
    <script src="../estilos/jquery.js"></script>
    <script src="../estilos/script.js"></script>
    <script src="../estilos/script.responsive.js"></script>
<script src="../estilos/bootstrap-modal.js"></script>
     <script>
			function imprimir(){
		  var objeto=document.getElementById('imprimir');
		 var ventana=window.open('','_blank');  
		  ventana.document.write(objeto.innerHTML);  	  ventana.document.close();  
		  ventana.print(); 
		  ventana.close(); 
		}
	</script>
</head>

<body>
<div id="art-main">
<!--Inicio de encabezado-->
<?php include('../piezas/cabecera.php'); ?>
<!--Fín de encabezado-->
<div class="art-sheet clearfix">
        <div class="art-layout-wrapper">
            <div class="art-content-layout">
                <div class="art-content-layout-row">
                    <!--Seccion de bloque-->
                    <?php include('../piezas/bloque.php'); ?>
                    <!--Fin de seccion de bloque-->
                    <div class="art-layout-cell art-content"><article class="art-post art-article">
                        <div class="art-postmetadataheader">
                        <h2 class="art-postheader"><span class="art-postheadericon">
                          <?php
							echo "BOLETA BIMESTRAL DE NOTAS";// - ".$nombrePerio;
						?></span>
                        </h2>
                        </div>
                                
                        <div class="art-postcontent art-postcontent-0 clearfix" id="imprimir" style=" overflow-y:scroll; overflow-x:scroll;  width:100%">
                      <!-- ...-->
                       		
			<?php
			
				function ObtenerNavegador($user_agent) 
				{
					$navegadores = array(
					'Opera' => 'Opera',
					'Mozilla Firefox'=> '(Firebird)|(Firefox)',
					'Galeon' => 'Galeon',
					'Mozilla'=>'Gecko',
					'MyIE'=>'MyIE',
					'Lynx' => 'Lynx',
					'Netscape' => '(Mozilla/4\.75)|(Netscape6)|(Mozilla/4\.08)|(Mozilla/4\.5)|(Mozilla/4\.6)|(Mozilla/4\.79)',
					'Konqueror'=>'Konqueror',
					'Internet Explorer 7' => '(MSIE 7\.[0-9]+)',
					'Internet Explorer 6' => '(MSIE 6\.[0-9]+)',
					'Internet Explorer 5' => '(MSIE 5\.[0-9]+)',
					'Internet Explorer 4' => '(MSIE 4\.[0-9]+)',
				);
				foreach($navegadores as $navegador=>$pattern)
				{
					if (eregi($pattern, $user_agent)) return $navegador;
						}
					return 'Desconocido';
				}
				include("../includes/conectar_sgi.inc");
				$db_link = mssql_select_db($db,$link) or die ("Fuera de servicio temporalmente");
				//echo $codi_usua_intra;
				$queryAlum = "SELECT apePaterPerso,apeMaterPerso,nombrePerso from TPersona inner join TAlumno on TPersona.codiPersona = TAlumno.codiPersona where TAlumno.codiAlum = '$codi_usua_intra'";
				$resultAlum = mssql_query($queryAlum);
				$rowAlum = mssql_fetch_array($resultAlum);
				$nombreAlum = $rowAlum['apePaterPerso']." ".$rowAlum['apeMaterPerso']." ".$rowAlum['nombrePerso'];
		//		$fecha = date('d M Y H:i:s');
				$fecha = date('d-m-Y H:i:s');
				//echo ' \ - / ' . $fecha;

				$nombreNave = ObtenerNavegador($_SERVER['HTTP_USER_AGENT']);

				if (isset($_POST['ddlb_perio_lecti']))
				{
					$codiPerio = $_POST['ddlb_perio_lecti'];
					if (strlen($codiPerio) != 6)
					{
						$bandeInco = 1;
					}
					else
					{
						$bandeInco = 0;
					}
				}
				else
				{
					$queryUltiPerioAlum = "Select max(codiPerio) as codiPerio from TMatriculaColegio where codiAlum = '$codi_usua_intra'";
					$resultUltiPerioAlum = mssql_query($queryUltiPerioAlum);
					$rowUltiPerioAlum = mssql_fetch_array($resultUltiPerioAlum);
					$codiPerio = $rowUltiPerioAlum['codiPerio'];
				}

				$qCantiMatri = "SELECT count(codiMatriCole) as cantiMatri from TMatriculaColegio where codiPerio = '$codiPerio' and codiAlum = '$codi_usua_intra'";
				$rCantiMatri = mssql_query($qCantiMatri);
				$rowCantiMatri = mssql_fetch_array($rCantiMatri);
				$cantiMatriA = $rowCantiMatri['cantiMatri'];

				$queryNombrePerio = "SELECT anioPerio from TPeriodoLectivo where codiPerio = '$codiPerio'";
				$resultNombrePerio = mssql_query($queryNombrePerio);
				$rowNombrePerio = mssql_fetch_array($resultNombrePerio);
				$nombrePerio = $rowNombrePerio['anioPerio'];

				$queryInfoAlum = "SELECT TMatriculaColegio.codiMatriCole, TSeccion.denoSeccion, TSeccion.nombreSeccion, TGrado.nombreGrado, TNivel.nombreNivel, TMatriculaColegio.codiInterAlumCole, dbo.TSeccion.codiNivel, dbo.TSeccion.codiGrado, dbo.TSeccion.codiSeccion FROM TMatriculaColegio INNER JOIN TSeccion ON TMatriculaColegio.codiPerio = TSeccion.codiPerio AND TMatriculaColegio.codiNivel = TSeccion.codiNivel AND TMatriculaColegio.codiGrado = TSeccion.codiGrado AND TMatriculaColegio.codiSeccion = TSeccion.codiSeccion INNER JOIN TGrado ON TSeccion.codiNivel = TGrado.codiNivel AND TSeccion.codiGrado = dbo.TGrado.codiGrado INNER JOIN TNivel ON TGrado.codiNivel = TNivel.codiNivel where TMatriculaColegio.codiPerio = '$codiPerio' and TMatriculaColegio.codiAlum = '$codi_usua_intra'";
				$resultInfoAlum = mssql_query($queryInfoAlum);
				$rowInfoAlum = mssql_fetch_array($resultInfoAlum);
				$codiMatriCole = $rowInfoAlum['codiMatriCole'];
				$codiNivel = $rowInfoAlum['codiNivel'];
				$codiGrado = $rowInfoAlum['codiGrado'];
				$codiSeccion = $rowInfoAlum['codiSeccion'];
				$nivel = $rowInfoAlum['nombreNivel'];
				$grado = $rowInfoAlum['nombreGrado'];
				$seccion = $rowInfoAlum['denoSeccion']." - ".$rowInfoAlum['nombreSeccion'];
				$codiInter = $rowInfoAlum['codiInterAlumCole'];

				$qDeudaAlum = "Select count(codiDerePago) as cantiDeuda from mgtc_v_deuda_alum_cole where (codiAlum = '$codi_usua_intra') and (fechaUltiDiaPago < '$fecha') and codiMatriCole = '$codiMatriCole'";
				$rDeudaAlum = mssql_query($qDeudaAlum);
				$rowDeudaAlum = mssql_fetch_array($rDeudaAlum);
				$cantiDeuda = $rowDeudaAlum['cantiDeuda'];
				
				if ($cantiDeuda > 0)
				{
					echo "<script type=\"text/javascript\">alert(\"Tiene deudas pendientes - REGULARICE EN TESORERIA DE COLEGIO\");</script>";
				}
				else
				{
					if ($bandeInco == 1)
					{
						echo "<script type=\"text/javascript\">alert(\"Seleccione Periodo Lectivo\");</script>";
					}
					else
					{
						if ($cantiMatriA == 0)
						{
							echo "<script type=\"text/javascript\">alert(\"No hay registros para el periodo seleccionado\");</script>";
						}
					}
				}

				$queryProgra = "SELECT codiPrograSPUC FROM TProgramaSPUC where codiGrado = '$codiGrado' and codiPerio = '$codiPerio'";
				$resultProgra = mssql_query($queryProgra);
				$rowProgra = mssql_fetch_array($resultProgra);
				$codiProgra = $rowProgra['codiPrograSPUC'];
			?>
			<div id="cuerpo_intra">
			<!--
				<div id="mensaje">
					La Boleta de Notas se entregará el día 28 de Octubre a partir de las 07:00 p.m.				</div>
			-->
				<div id="conteBole">
				<div id="opciones1">
				</div>
				<div id="opciones">
						<!--<form method="post" action="boleta.php?codi='$codi_usua_intra'" name="formu_opcion">-->
                        <form action="" method="post" name="formu_opcion">
							<div >
								<?php
									include '../includes/conectar_intra_2.php';
									$consultaQuery = "Select TMatriculaColegio.codiPerio, TPeriodoLectivo.nombrePerio from  TMatriculaColegio 
inner join TPeriodoLectivo on TMatriculaColegio.codiPerio = TPeriodoLectivo.codiPerio
inner join TProgramaSPUC on  TProgramaSPUC.codiGrado = TMatriculaColegio.codiGrado
where codiAlum ='".$codi_usua_intra."' 
group by TMatriculaColegio.codiPerio, TPeriodoLectivo.nombrePerio
order by TMatriculaColegio.codiPerio desc";
									$consulta = mssql_query($consultaQuery);
								?>
                              <strong> Selecciona Periodo Lectivo:</strong>        <select name="ddlb_perio_lecti" id="ddlb_perio_lecti"  onChange="this.form.submit()">
            <option value='0'>-- Seleccione --</option>
                                       <?php while($registro=mssql_fetch_array($consulta))
				{
						?>
                                       <OPTION value="<?php echo $registro['codiPerio'];?>" <?php if ($registro['codiPerio'] == $codiPerio ) { echo 'selected';}?>   ><?php echo utf8_encode($registro['nombrePerio']);?></OPTION>
                                       <?php 
						}
						?>
                                     </select>
							</div>
							


							<div id="mostrar">
								<?php
									if ($nombreNave == "Internet Explorer 6")
									{
										$mensa = "PorFavor antes de Imprimir Configure el papel en posición Horizontal";
										$mensa = str_replace(" ","_",$mensa);
									}
								?>
							<!--	<a href="boleta.php?codi=<?php echo $codi_usua_intra; ?>&codiPerio=<?php echo $codiPerio; ?>&mensa=<?php echo $mensa; ?>" target="_blank" onClick="window.open(this.href, this.target, 'width=900,height=650'); return false;"><input name="cb_imprimir" type="button" class="art-button"  onclick="javascript:mensaje('<?php echo $mensa; ?>')" value="Imprimir" /></a>-->
							</div>
							
						</form>
					</div>
					<div id="tituBole" >
						<?php
							echo "BOLETA BIMESTRAL DE NOTAS - ".$nombrePerio;
						?>
					</div>
					
					<div id="datosAlum">
						<div id="datos">
							<div id="cuerpoEti">
								<div id="eti">
									Código:
								</div>
								<div id="eti">
									Alumno:
								</div>
							</div>
							<div id="cuerpoObje">
								<div id="obje">
									<?php echo $codiInter; ?>
								</div>
								<div id="obje">
								  <?php
										echo $nombreAlum;
									?>
								</div>
							</div>
						</div>
						<div id="datosSeccion">
							<div id="cuerpoEti">
								<div id="eti">
									Grado:
								</div>
								<div id="eti">
									Sección:
								</div>
							</div>
							<div id="cuerpoObje1">
								<div id="obje1">
									<?php echo utf8_encode($grado." ".$nivel); ?>
								</div>
								<div id="obje1">
									<?php echo $seccion; ?>
								</div>
							</div>
						</div>
					</div>
					
					<div id="cuerpoRepor">
						<div id="notas">
							<div id="numero">
								<div id="titu">
								</div>
								<div id="cuerpo">
									<?php
										$nombreCursos = array();
										$cursos = array();
										$queryCurso = "SELECT distinct codiCursoAca FROM TPromedioBimestralSPUC where codiMatriCole = '$codiMatriCole'";
										$resultCurso = mssql_query($queryCurso);
										while ($rowCurso=mssql_fetch_array($resultCurso))
										{
											$queryNombreCurso="SELECT nombreCursoAca FROM TCursoAcademia where codiCursoAca = '".$rowCurso['codiCursoAca']."' ";
											$resultNombreCurso = mssql_query($queryNombreCurso);
											$rowNombreCurso = mssql_fetch_array($resultNombreCurso);
											$j = $j + 1;
											$nombreCursos[$j] = $rowNombreCurso['nombreCursoAca'];
											$cursos[$j] = $rowCurso['codiCursoAca'];
										}
										if (count($nombreCursos)>1)
										{
											for($i=1;$i<=count($nombreCursos);$i++)
											{
												if ($i == 1)
												{
													$concaCurso = "<div id='capaNombreCurso'>".$nombreCursos[$i]."</div>";
													$concaNume = "<div id='capaNume'>".$i."</div>";
												}
												else
												{
													if ($i == count($nombreCursos))
													{
														if ($codiGrado == 'G13')
														{
															$concaCurso = $concaCurso."<div id='capaNombreCurso'><span style=font-weight:bold>".$nombreCursos[$i]." * </span></div>";
														}
														else
														{
															$concaCurso = $concaCurso."<div id='capaNombreCurso'>".$nombreCursos[$i]."</div>";
															$concaNume = $concaNume."<div id='capaNume'>".$i."</div>";
														}
													}
													else
													{
														$concaCurso = $concaCurso."<div id='capaNombreCurso'>".$nombreCursos[$i]."</div>";
														$concaNume = $concaNume."<div id='capaNume'>".$i."</div>";
													}												
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaNume;
											}
										}
									
									?>
								</div>
							</div>
							<div id="asignatura">
								<div id="titu">
									Asignaturas
								</div>
								<div id="cuerpo">
									<?php
										if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
										{
											echo utf8_encode($concaCurso);
										}
									?>
								</div>
							</div>
							<div id="bimestre">
								<div id="titu">
									<?php
									
										$bimestres = array();
										$notasBimestres = array();
										$promediosVerti = array();
										$promediosHori = array();
										$puntaje = array();
										$bimePueba = array();
										$queryBimePrueba = "Select codiPerioEva from TProgramaPeriodoSPUC where codiPrograSPUC = '$codiProgra' and estaPerioActual = 1 ";
										$resultBimePrueba = mssql_query($queryBimePrueba);
										while($rowBimePrueba = mssql_fetch_array($resultBimePrueba))
										{
											$queryNombrePerio="SELECT nombrePerioEva FROM TPeriodoEvaluacion where codiPerioEva = '".$rowBimePrueba['codiPerioEva']."' ";
											$resultNombrePerio = mssql_query($queryNombrePerio);
											$rowNombrePerio = mssql_fetch_array($resultNombrePerio);
											$nombrePerioEva = $rowNombrePerio['nombrePerioEva'];
													
											$x = $x + 1;
											$bimePrueba[$x] = $rowBimePrueba['codiPerioEva'];
										}
										$bimes = array();
										$codiBimes = array();
										$queryBimes = "Select codiPerioEva,nombreBrevePerioEva FROM TPeriodoEvaluacion where codiTipoPerioEva='TPE01'";
										$resultBimes = mssql_query($queryBimes);
										while($rowBimes = mssql_fetch_array($resultBimes))
										{
											$cantiBimes = $cantiBimes + 1;
											$nombreBreve = $rowBimes['nombreBrevePerioEva'];
											if ($cantiBimes == 1)
											{
												$concaNombreBimes = "<div id='capaNombreBim'><span style=font-weight:bold>".$nombreBreve."</span></div>";
												$concaNombreBimes1 = "<div id='capaNombreBim1'><span style=font-weight:bold>".$nombreBreve."</span></div>";
												$concaNombreBimes2 = "<div id='capaNombreBim2'>".$nombreBreve."</div>";
											}
											else
											{
												$concaNombreBimes = $concaNombreBimes."<div id='capaNombreBim'><span style=font-weight:bold>".$nombreBreve."</span></div>";
												$concaNombreBimes1 = $concaNombreBimes1."<div id='capaNombreBim1'><span style=font-weight:bold>".$nombreBreve."</span></div>";
												$concaNombreBimes2 = $concaNombreBimes2."<div id='capaNombreBim2'>".$nombreBreve."</div>";
											}
											$bimes[$cantiBimes] = $nombreBreve;
											$codiBimes[$cantiBimes] = $rowBimes['codiPerioEva'];
										}
										echo $concaNombreBimes2;
									
									?>
								</div>
								<div id="cuerpo">
									<?php
									//echo "cantidad: " . count($cursos);	 
									if (count($cursos)> 1)
									{
											for($k=1;$k<=count($cursos);$k++)
											{
												//echo ' |k ' . $l;
												if ($bimePrueba == '')
												{$bimePrueba ='1';}
												for($l=1;$l<=count($bimePrueba);$l++)
												{
													//echo ' |l ' . $l;
													$codiCurso = $cursos[$k];
													$codiPerioEva1 = $bimePrueba[$l];
													
													$querynota="SELECT promeBimes FROM TPromedioBimestralSPUC where codiMatriCole = '$codiMatriCole' and codiCursoAca = '$codiCurso' and codiPerioEva = '$codiPerioEva1' ";
														//echo $codiMatriCole . " - " . $codiCurso . " - " . $codiPerioEva1;
														$resultnota = mssql_query($querynota);
														$rownota = mssql_fetch_array($resultnota);
														
														$notasBimestres[$k][$l] = $rownota['promeBimes'];
														/*if ($notasBimestres[$k][$l] == '' )
														{ $notasBimestres[$k][$l] = '-';}*/
														//echo '|' . $k.'|'.$l.'|= '.$notasBimestres[$k][$l] . ' // ';
														/*if ($codiPerioEva1 == 'PB01')
														{
															echo $notasBimestres[$k][$l] . " - " ;
														}*/			
														if ($codiCurso != '22')
														{
															
															$acumProme = $acumProme + $notasBimestres[$k][$l];
															 
															
															//if ($codiPerioEva1 == 'PB01')
															//{echo $acumProme . " - " . $codiPerioEva1 . "\n";}
														}
													
												}
												//$prome1 = round(($acumProme/count($bimePrueba))*100)/100;
												$prome1 = round(($acumProme/count($bimePrueba)));
												
												$promediosVerti[$k] = $prome1;
												$acumProme = 0;
												//echo "acum" . " = " . $promediosVerti[$k] . " - ";
											}
											for($k=1;$k<=count($cursos);$k++)
											{	
												if ($k == 1)
												{
													$concaProme = "<div id='capaNotaBimes'>";
												}
												else
												{
													$concaProme = $concaProme."<div id='capaNotaBimes'>";
												}
												//echo ' ||| ' . count($bimeprueba);

												for($l=1;$l<=count($bimePrueba);$l++)
												{
													if ($notasBimestres[$k][$l] < 11)
													{
														$concaProme = $concaProme."<div id='notaBimes'><span style=font-weight:bold>".$notasBimestres[$k][$l]."</span></div>";
													}
													else
													{
														$concaProme = $concaProme."<div id='notaBimes'>".$notasBimestres[$k][$l]."</div>";
													}
													if ($l == count($bimePrueba))
													{
														$concaProme = $concaProme."</div>";
													}
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaProme;
											}
											$acum = 0;
											for($k=1;$k<=count($bimePrueba);$k++)
											{
												for($l=1;$l<=count($cursos);$l++)
												{
													if ($codiGrado == "G13")
													{
														if ($l != count($cursos) + 1)
														{
															if ((strlen($notasBimestres[$l][$k])!= 0) and (strtoupper($notasBimestres[$l][$k])!="EXO"))
															{
																//echo $notasBimestres[$l][$k];
																if ($l != count($cursos) - 1)
																{
																	$acum = $acum + $notasBimestres[$l][$k];
																	$canti = $canti + 1;
																}
															}
														}
													}
													else
													{
														if ((strlen($notasBimestres[$l][$k])!= 0) and (strtoupper($notasBimestres[$l][$k])!="EXO"))
														{
															if ($l != count($cursos) - 1)
															{
																$acum = $acum + $notasBimestres[$l][$k];
																$canti = $canti + 1;
															}
														}
													}
													//echo $acum . " - ";
													//$acum = $acum - $notasBimestres[20][$k];
												}
												if ($canti > 0)
												{ 
													$prom = $acum/($canti);
													$promediosHori[$k] = round($prom * 100)/100;
													$puntaje[$k] = $acum;
													$acum = 0;
													$canti = 0;
												}
											}
										}
									
									?>
								</div>
							</div>
							<div id="promedio">
								<div id="titu">
									<!--P. Final-->
							  </div>
								<div id="cuerpo">
									<?php
									
										for($i=1;$i<=count($promediosVerti);$i++)
										{
											if ($i == 1)
											{
												//echo " aqui " . $promediosVerti[$i];
												$concaPromeVerti = "<div id='capaPromeVerti'>".$promediosVerti[$i]."</div>";
											}
											else
											{
												$concaPromeVerti = $concaPromeVerti."<div id='capaPromeVerti'>".$promediosVerti[$i]."</div>";
											}
										}
									//echo $concaPromeVerti;
									?>
								</div>
							</div>
							
							<div id="promeHoriFinal">
								<div id="nume1">
								</div>
								<div id="asig1">
									<div id="etiNotaProme">
										Nota Promedio:
									</div>
									<div id="etiNotaProme">
										Puntaje:
									</div>
								</div>
								<div id="bime1">
									<div id="objeNotaProme">
										<?php
										
											for($i=1;$i<=count($promediosHori);$i++)
											{
												if ($i == 1)
												{
													$concaProme1 = "<div id='capaPromeHori'><div id='promeHori'><span style=font-weight:bold>".$promediosHori[$i]."</span></div>";
												}
												else
												{
													$concaProme1 = $concaProme1."<div id='promeHori'><span style=font-weight:bold>".$promediosHori[$i]."</span></div>";
												}
												if ($i==count($promediosHori))
												{
													$concaProme1 = $concaProme1."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaProme1;
											}
										?>
									</div>
									<div id="objeNotaProme">
										<?php
											
											for($i=1;$i<=count($puntaje);$i++)
											{
//												echo $i . " - " . $puntaje[$i] . "\n";
												if ($i == 1)
												{
													$concaProme2 = "<div id='capaPromeHori'><div id='promeHori'><span style=font-weight:bold>".$puntaje[$i]."</span></div>";
												}
												else
												{
													$concaProme2 = $concaProme2."<div id='promeHori'><span style=font-weight:bold>".$puntaje[$i]."</span></div>";
												}
												if ($i==count($puntaje))
												{
													$concaProme2 = $concaProme2."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaProme2;
											}
										?>
									</div>
								</div>
								<div id="prome1">
									<div id="promeFinal">
										<?php
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												for($i=1;$i<=count($promediosHori);$i++)
												{
													$acumFinalHori = $acumFinalHori + $promediosHori[$i];
												}
												for($i=1;$i<=count($promediosVerti)-1;$i++)
												{
													$acumFinalVerti = $acumFinalVerti + $promediosVerti[$i];
												}
												if (count($promediosHori) > 0)
												{
													$promeFinalHori = round(($acumFinalHori/count($promediosHori))*100)/100;
												}
												if (count($promediosVerti) > 0)
												{
													$promeFinalVerti = round(($acumFinalVerti/(count($promediosVerti)-1))*100)/100;
												}
											}
										//echo $promeFinalVerti;
										?>
                                        
									</div>
									<div id="promeFinal">
										<?php
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												for ($i=1; $i<=count($puntaje); $i++)
												{
													$acumPuntaje = $acumPuntaje + $puntaje[$i];
												}
												if (count($puntaje) > 0)
												{
													$promeFinalPuntaje = round(($acumPuntaje/count($puntaje))*100)/100;
												}
											}
											//echo $promeFinalPuntaje;
										?>
									</div>
								</div>
							</div>
							
						</div>
						<div id="asistencia">
							<div id="merito">
								<div id="tituMeri">
									Mérito
								</div>
								<div id="etiMeri">
									<div id="bim">
										Bimestre
									</div>
									<div id="aula">
										Aula
									</div>
									<div id="grado">
										Grado
									</div>
								</div>
								<div id="cuerpoMeri">
									<div id="cuerpoBim">
										<?php
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaNombreBimes;
											}
										?>
									</div>
									<div id="cuerpoMeriAula">
										<?php
											$meriAula = array();
											for($i=1;$i<=count($bimePrueba);$i++)
											{
												$codiPerioEva = $bimePrueba[$i];

												$queryMeri = "SELECT promeFinal FROM TMeritoSPUC where codiMatriCole = '$codiMatriCole' and codiPerioEva = '$codiPerioEva' and codiGrado = '$codiGrado' and codiPerio = '$codiPerio'";
												$resultMeri = mssql_query($queryMeri);
												$rowMeri = mssql_fetch_array($resultMeri);
												$promeFinal = $rowMeri['promeFinal'];
												//echo $promeFinal;
												$queryMeriAula1 = "SELECT distinct promeFinal FROM TMeritoSPUC where codiPerioEva = '$codiPerioEva' and codiGrado = '$codiGrado' and codiSeccion = '$codiSeccion' and codiPerio = '$codiPerio' order by promeFinal DESC";
												$resultMeriAula1 = mssql_query($queryMeriAula1);
												while ($rowMeriAula1=mssql_fetch_array($resultMeriAula1))
												{
													$contaMeriAula1 = $contaMeriAula1 + 1;
												}
												$queryMeriAula = "SELECT distinct promeFinal FROM TMeritoSPUC where codiPerioEva = '$codiPerioEva' and codiGrado = '$codiGrado' and codiSeccion = '$codiSeccion' and codiPerio = '$codiPerio' order by promeFinal DESC";
												$resultMeriAula = mssql_query($queryMeriAula);
												
												while ($rowMeriAula=mssql_fetch_array($resultMeriAula))
												{
													$contaMeriAula = $contaMeriAula + 1;
													
													if ($rowMeriAula['promeFinal'] == $promeFinal)
													{
														$ordenMeriAula = $contaMeriAula;
														$meriAula[$i] = $ordenMeriAula."/".$contaMeriAula1;
														$contaMeriAula = 0;
														break;
													}
													
												}
												$contaMeriAula1 = 0;
											}
											for($i=1;$i<=count($meriAula);$i++)
											{
												$valor = $meriAula[$i];
												if ($i == 1)
												{
													$concaNombreBimes5 = "<div id='capaNombreBim'>".$valor."</div>";
												}
												else
												{
													$concaNombreBimes5 = $concaNombreBimes5."<div id='capaNombreBim'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaNombreBimes5;
											}
										?>
									</div>
									<div id="cuerpoMeriGrado">
										<?php
										
											$meriGrado = array();
											$promeMeritos = array();
											for($i=1;$i<=count($bimePrueba);$i++)
											{											
												$codiPerioEva2 = $bimePrueba[$i];
												
												$queryMeri = "SELECT promeFinal FROM TMeritoSPUC where codiMatriCole = '$codiMatriCole' and codiPerioEva = '$codiPerioEva2' and codiGrado = '$codiGrado' and codiPerio = '$codiPerio'";
												$resultMeri = mssql_query($queryMeri);
												$rowMeri = mssql_fetch_array($resultMeri);
												$promeFinal = $rowMeri['promeFinal'];
												
												$queryProme1 = "SELECT distinct promeFinal FROM TMeritoSPUC where codiPerioEva = '$codiPerioEva2' and codiGrado = '$codiGrado' and codiPerio = '$codiPerio' order by promeFinal DESC";
												$resultProme1 = mssql_query($queryProme1);
											
												while ($rowProme1=mssql_fetch_array($resultProme1))
												{
													$contaOrden1 = $contaOrden1 + 1;
												}
												
												$queryProme = "SELECT distinct promeFinal FROM TMeritoSPUC where codiPerioEva = '$codiPerioEva2' and codiGrado = '$codiGrado' and codiPerio = '$codiPerio' order by promeFinal DESC";
												$resultProme = mssql_query($queryProme);
											
												while ($rowProme=mssql_fetch_array($resultProme))
												{
													$contaOrden = $contaOrden + 1;
													if ($rowProme['promeFinal'] != $promeFinal)
													{
														$promeMeritos[$contaOrden] = $rowProme['promeFinal'];
													}
													else
													{
														$ordenMerito = $contaOrden;
														$meriGrado[$i] = $ordenMerito."/".$contaOrden1;
														$contaOrden = 0;
														break;
													}
												}
												$contaOrden1 = 0;
											}
											for($i=1;$i<=count($meriGrado);$i++)
											{
												$valor = $meriGrado[$i];
												if ($i == 1)
												{
													$concaNombreBimest = "<div id='capaNombreBim'>".$valor."</div>";
												}
												else
												{
													$concaNombreBimest = $concaNombreBimest."<div id='capaNombreBim'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaNombreBimest;
											}
										?>
									</div>
								</div>
								<div id="pieMerito">
									<div id="final">
										Final
									</div>
									<div id="finalAula">
									<?php

										$bimesFinal = array();
										$codiMatri = array();
										$notasFinal = array();

										$queryCodiMatri = "Select DISTINCT codiMatriCole from TMeritoSPUC where codiGrado = '$codiGrado' and codiSeccion = '$codiSeccion'";
										$resultCodiMatri = mssql_query($queryCodiMatri);
										while($rowCodiMatri = mssql_fetch_array($resultCodiMatri))
										{
											$cantiCodiMatri = $cantiCodiMatri + 1;
											$codiMatri[$cantiCodiMatri] = $rowCodiMatri['codiMatriCole'];
										}
										$queryPrograSPUC = "Select codiPerioEva from TProgramaPeriodoSPUC where codiPrograSPUC = '$codiProgra' and estaPerioActual = 1";
										$resultPrograSPUC = mssql_query($queryPrograSPUC);
										while($rowPrograSPUC = mssql_fetch_array($resultPrograSPUC))
										{
											$cantiBimesFina = $cantiBimesFina + 1;
											$bimesFinal[$cantiBimesFina] = $rowPrograSPUC['codiPerioEva'];
										}
										for($i=1;$i<=count($codiMatri);$i++)
										{
											for($j=1;$j<=count($bimesFinal);$j++)
											{
												$queryNotaFinal = "Select promeFinal from TMeritoSPUC where codiMatriCole = '$codiMatri[$i]' and codiPerioEva = '$bimesFinal[$j]'";
												$resultNotaFinal = mssql_query($queryNotaFinal);
												$rowNotaFinal = mssql_fetch_array($resultNotaFinal);
												$acumPromeFinal = $acumPromeFinal + $rowNotaFinal['promeFinal'];
											}
											if (count($bimesFinal) > 0)
											{
												$promeTotal = round(($acumPromeFinal/count($bimesFinal))*100)/100;
												$notasFinal[$codiMatri[$i]] = $promeTotal;
												$acumPromeFinal = 0;
												$promeTotal = 0;
											}
										}
										rsort($notasFinal);
										$notasFinalGrado = array_unique($notasFinal);
										$prueba1 = (array_values($notasFinalGrado));
										for ($i=0;$i<count($prueba1);$i++)
										{
											if ($promeFinalHori != $prueba1[$i])
											{
												$posiFinal = $posiFinal + 1;
											}
											else
											{
												$posiFinal = $posiFinal + 1;
												break;
											}
											
										}
										//echo $posiFinal."/".count($prueba1);
//										echo $promeFinalHori;
									
									?>
									</div>
									<div id="finalGrado">
										<?php
										
											$codiMatriGrado = array();
											$notasFinalGrado = array();
											$notasFinalGradoLimpio = array();
											$prueba = array();
												
											$queryCodiMatriGrado = "Select DISTINCT codiMatriCole from TMeritoSPUC where codiGrado = '$codiGrado'";
											$resultCodiMatriGrado = mssql_query($queryCodiMatriGrado);
											while($rowCodiMatriGrado = mssql_fetch_array($resultCodiMatriGrado))
											{
												$cantiCodiMatriGrado = $cantiCodiMatriGrado + 1;
												$codiMatriGrado[$cantiCodiMatriGrado] = $rowCodiMatriGrado['codiMatriCole'];
											}
											
											for($i=1;$i<=count($codiMatriGrado);$i++)
											{
												for($j=1;$j<=count($bimesFinal);$j++)
												{
													$queryNotaFinalGrado = "Select promeFinal from TMeritoSPUC where codiMatriCole = '$codiMatriGrado[$i]' and codiPerioEva = '$bimesFinal[$j]'";
													$resultNotaFinalGrado = mssql_query($queryNotaFinalGrado);
													$rowNotaFinalGrado = mssql_fetch_array($resultNotaFinalGrado);
													$acumPromeFinalGrado = $acumPromeFinalGrado + $rowNotaFinalGrado['promeFinal'];
												}
												if (count($bimesFinal) > 0)
												{
													$promeTotalGrado = round(($acumPromeFinalGrado/count($bimesFinal))*100)/100;
													$notasFinalGrado[$codiMatriGrado[$i]] = $promeTotalGrado;
													$acumPromeFinalGrado = 0;
													$promeTotalGrado = 0;
												}
											}
											rsort($notasFinalGrado);
											$notasFinalGradoLimpio = array_unique($notasFinalGrado);
											$prueba = (array_values($notasFinalGradoLimpio));
											
											for ($i=0;$i<count($prueba);$i++)
											{
												if ($promeFinalHori != $prueba[$i])
												{
													$posiFinalGrado = $posiFinalGrado + 1;
												}
												else
												{
													$posiFinalGrado = $posiFinalGrado + 1;
													break;
												}
												
											}
											//echo $posiFinalGrado."/".count($prueba);
										
										?>
									</div>
								</div>
							</div>
							<div id="reporAsis">
								<div id="tituReporAsis">
									Asistencia
								</div>
								<div id="etiReporAsis">
									<div id="bimeAsis">
										Bim
									</div>
									<div id="FJ">
										FJ
									</div>
									<div id="FI">
										FI
									</div>
									<div id="TJ">
										TJ
									</div>
									<div id="TI">
										TI
									</div>
								</div>
								<div id="cuerpoReporAsis">
									<div id="cuerpoBimeAsis">
										<?php
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaNombreBimes1;
											}
											$FJ = array();
											$FI = array();
											$TJ = array();
											$TI = array();
											for($i=1;$i<=count($bimePrueba);$i++)
											{
											$codi = $bimePrueba[$i];
											$queryCrono = "SELECT codiCrono from TCronogramaAsistenciaSPUC where codiPerioEva ='$codi'";
											$resultCrono = mssql_query($queryCrono);
											$faltasJusti = 0;$totalFaltas = 0;$tardanJusti = 0;$totalTardan = 0;
											while ($rowCrono=mssql_fetch_array($resultCrono))
											{
												$queryAsis="SELECT diaLunes,diaMartes,diaMierco,diaJueves,diaViernes,diaSabado,diaDomingo FROM TAsistenciaSPUC where codiCrono = '".$rowCrono['codiCrono']."' and codiMatriCole = '$codiMatriCole' and codiTurno = 'TC01'";
												$resultAsis = mssql_query($queryAsis);
												
												while ($rowAsis = mssql_fetch_array($resultAsis))
												{
													if ($rowAsis['diaLunes']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaLunes']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaLunes']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaLunes']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaMartes']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaMartes']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaMartes']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaMartes']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaMierco']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaMierco']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaMierco']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaMierco']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaJueves']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaJueves']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaJueves']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaJueves']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaViernes']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaViernes']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaViernes']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaViernes']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaSabado']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaSabado']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaSabado']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaSabado']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
													if ($rowAsis['diaDomingo']=="TJ")
													{
														$tardanJusti = $tardanJusti + 1;
														$totalTardan = $totalTardan + 1;
													}
													else
													{
														if ($rowAsis['diaDomingo']=='T')
														{
															$tardan = $tardan + 1;
															$totalTardan = $totalTardan + 1;
														}
														else
														{
															if ($rowAsis['diaDomingo']=='FJ')
															{
																$faltasJusti = $faltasJusti + 1;
																$totalFaltas = $totalFaltas + 1;
															}
															else
															{
																if($rowAsis['diaDomingo']=='F')
																{
																	$falta = $falta + 1;
																	$totalFaltas = $totalFaltas + 1;
																}
															}
														}
													}
												}
											}
											$FJ[$i] = $faltasJusti;
											$FI[$i] = $totalFaltas - $faltasJusti;;
											$TJ[$i] = $tardanJusti;
											$TI[$i] = $totalTardan - $tardanJusti;
											$faltasJusti = 0;$totalFaltas = 0;$tardanJusti = 0;$totalTardan = 0;
											}
										?>
									</div>
									<div id="cuerpoFJ">
										<?php
										
											for($i=1;$i<=count($FJ);$i++)
											{
												$valor = $FJ[$i];
												if ($i == 1)
												{
													$concaAsis = "<div id='capaAsis'>".$valor."</div>";
												}
												else
												{
													$concaAsis = $concaAsis."<div id='capaAsis'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaAsis;
											}
										?>
									</div>
									<div id="cuerpoFI">
										<?php
										
											for($i=1;$i<=count($FI);$i++)
											{
												$valor = $FI[$i];
												if ($i == 1)
												{
													$concaAsis = "<div id='capaAsis'>".$valor."</div>";
												}
												else
												{
													$concaAsis = $concaAsis."<div id='capaAsis'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaAsis;
											}
										?>
									</div>
									<div id="cuerpoTJ">
										<?php
										
											for($i=1;$i<=count($TJ);$i++)
											{
												$valor = $TJ[$i];
												if ($i == 1)
												{
													$concaAsis = "<div id='capaAsis'>".$valor."</div>";
												}
												else
												{
													$concaAsis = $concaAsis."<div id='capaAsis'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaAsis;
											}
										?>
									</div>
									<div id="cuerpoTI">
										<?php
											for($i=1;$i<=count($TI);$i++)
											{
												$valor = $TI[$i];
												if ($i == 1)
												{
													$concaAsis = "<div id='capaAsis'>".$valor."</div>";
												}
												else
												{
													$concaAsis = $concaAsis."<div id='capaAsis'>".$valor."</div>";
												}
											}
											if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
											{
												echo $concaAsis;
											}
										?>
									</div>
								</div>
							</div>
							<div id="cuadroEsta">
							  <?php
									if (count($codiBimes)-count($promediosHori)!=0)
									{
										for ($i = count($promediosHori)+1;$i<=count($codiBimes);$i++)
										{
											$promediosHori[$i] = 0;
										}
									}
									$var = implode(" ", $promediosHori);
									if (($cantiDeuda == 0) and ($bandeInco == 0) and ($cantiMatriA > 0))
									{
										echo "<img src = \"grafico-barra2.php?codi=$var\" />";
									}
								?>
							</div>
					  </div>
					</div>
				</div>
			</div>
                       <!--..-->
                        </div>
                    </article></div>
                </div>
            </div>
        </div>
</div>
<!--Inicio pie de página-->
<?php include('../piezas/pie.php'); ?>
<!--Fín pie de página-->
</div>

</body></html>
<?

}
else
{ 
  echo "No ha validado su sessión";
}

?>	