<?php
/*
	include("graficos/jpgraph.php");
	include("graficos/jpgraph_bar.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);

	$graph = new Graph(280,200);
	$graph->SetScale("textlin");
	$graph->img->SetMargin(60,30,20,40);
	$graph->yaxis->SetTitleMargin(45);
	$graph->yaxis->scale->SetGrace(10);
	$graph->SetShadow();
	
	$graph->xaxis->SetTickSide(SIDE_DOWN);
	$graph->yaxis->SetTickSide(SIDE_LEFT);
	
	$bplot = new BarPlot($datay);
	$bplot->SetFillColor("#620000");
	
	$bplot->SetShadow();
	$bplot->value->SetFormat("%2.1f",70);
	$bplot->value->SetFont(FF_ARIAL,FS_NORMAL,9);
	$bplot->value->SetColor("#620000");
	$bplot->value->Show();
	
	$graph->Add($bplot);
	
	$graph->title->Set("Promedios Bimestrales");
	$graph->xaxis->title->Set("Bimestres");
	$graph->yaxis->title->Set("Notas");
	
	$graph->title->SetFont(FF_FONT1,FS_BOLD);
	$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
	$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
	
	$graph->Stroke();
*/
/*
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);
	
	$graph = new Graph(200,150,"auto");	
	$graph->SetScale("textlin");
	$graph->img->SetMargin(25,15,25,25);
	
	$graph->title->Set('"GRAD_MIDHOR"');
	$graph->title->SetColor('darkred');
	
	$graph->xaxis->SetFont(FF_FONT1);
	$graph->yaxis->SetFont(FF_FONT1);
	
	$bplot = new BarPlot($datay);
	$bplot->SetWidth(0.6);
	
	$bplot->SetFillGradient("navy","lightsteelblue",GRAD_MIDHOR);
	
	$bplot->SetColor("navy");
	$graph->Add($bplot);
	
	$graph->Stroke();
*/

	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);

	$graph = new Graph(250,200,"auto");	
	$graph->SetScale("textlin");
	$graph->img->SetMargin(35,25,35,35);
	
	$graph->title->Set('"Promedios Bimestrales"');
	$graph->title->SetColor('#620000');
	
	$graph->xaxis->SetFont(FF_FONT2);
	$graph->yaxis->SetFont(FF_FONT2);
	
	$bplot = new BarPlot($datay);
	$bplot->SetWidth(0.6);
	
	$bplot->SetFillGradient("#620000","white",GRAD_WIDE_MIDVER);
	
	$bplot->SetColor("#620000");
	$graph->Add($bplot);
	
	$graph->Stroke();

/*	
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);
	
	$graph = new Graph(200,150,"auto");	
	$graph->SetScale("textlin");
	$graph->img->SetMargin(25,15,25,25);
	
	$graph->title->Set('"Ex�menes Semanales"');
	$graph->title->SetColor('blue');
	
	$graph->xaxis->SetFont(FF_FONT1);
	$graph->yaxis->SetFont(FF_FONT1);
	
	$bplot = new BarPlot($datay);
	$bplot->SetWidth(0.6);
	
	$bplot->SetFillGradient("navy","lightsteelblue",GRAD_CENTER);
	
	$bplot->SetColor("navy");
	$graph->Add($bplot);
	
	$graph->Stroke();
*/
/*
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);
	
	$graph = new Graph(200,150,"auto");	
	$graph->SetScale("textlin");
	$graph->img->SetMargin(25,15,25,25);
	
	$graph->title->Set('"GRAD_RAISED_PANEL"');
	$graph->title->SetColor('darkred');
	
	$graph->xaxis->SetFont(FF_FONT1);
	$graph->yaxis->SetFont(FF_FONT1);
	
	$bplot = new BarPlot($datay);
	$bplot->SetWidth(0.6);
	
	$bplot->SetFillGradient('navy','orange',GRAD_RAISED_PANEL);
	
	$bplot->SetColor("navy");
	$graph->Add($bplot);
	
	$graph->Stroke();
*/
/*
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	include ("graficos/jpgraph_line.php");
	
	$cod = $_GET[codi];
	$datay = explode(" ", $cod);
	
	$graph = new Graph(250,200,'auto');	
	$graph->SetScale("textlin");
	
	$bplot = new BarPlot($datay);
	$bplot->SetFillColor("#620000");
	$bplot->SetWidth(0.5);
	
	$lplot = new LinePlot($datay);
	$lplot->SetColor('blue');
	$lplot->SetBarCenter();
	
	$graph->Add($bplot);
	$graph->Add($lplot);
	
	$graph->Stroke();
*/
/*
	//NO funciona
	include ("graficos/jpgraph.php"); 
	include ("graficos/jpgraph_line.php"); 
	include ("graficos/jpgraph_bar.php"); 
	
	$cod = $_GET[codi];

	$ydata = explode(" ", $cod);
	$ydata2 = explode(" ", $cod);
	$targ = explode(" ", $cod);
	$alt = explode(" ", $cod); 
	
	$graph = new Graph(300,200,"auto");     
	$graph->SetScale("textlin"); 
	$graph->img->SetMargin(40,20,30,40); 
	$graph->title->Set("CSIM example with bar and line"); 
	$graph->title->SetFont(FF_FONT1,FS_BOLD);
	
	$graph->xaxis->title->Set("X-title"); 
	$graph->yaxis->title->Set("Y-title"); 
	
	$lineplot=new LinePlot($ydata); 
	$lineplot->mark->SetType(MARK_FILLEDCIRCLE);
	$lineplot->mark->SetWidth(5);
	$lineplot->mark->SetColor('black');
	$lineplot->mark->SetFillColor('red');
	$lineplot->SetCSIMTargets($targ,$alt);
	
	$barplot=new barPlot($ydata2); 
	$barplot->SetCSIMTargets($targ,$alt);
	
	$graph->Add($lineplot); 
	$graph->Add($barplot); 
	
	$graph->StrokeCSIM();
*/
/*	
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	include ("graficos/jpgraph_line.php");
	
	$cod = $_GET[codi];
	$ydata  = explode(" ", $cod);
	$ydata2 = explode(" ", $cod);
		
	$months = $gDateLocale->GetShortMonth();
	
	$graph = new Graph(300,200);	
	$graph->SetScale("textlin");
	$graph->SetMarginColor('white');
	
	$graph->SetMargin(30,1,20,5);
	
	$graph->SetBox(); 
	
	$graph->SetFrame(false);
	
	$graph->tabtitle->Set('Year 2003');
	$graph->tabtitle->SetFont(FF_ARIAL,FS_BOLD,10);
	
	$graph->ygrid->SetFill(true,'#DDDDDD@0.5','#BBBBBB@0.5');
	$graph->ygrid->SetLineStyle('dashed');
	$graph->ygrid->SetColor('gray');
	$graph->xgrid->Show();
	$graph->xgrid->SetLineStyle('dashed');
	$graph->xgrid->SetColor('gray');
	
	$graph->xaxis->SetTickLabels($months);
	$graph->xaxis->SetFont(FF_ARIAL,FS_NORMAL,8);
	$graph->xaxis->SetLabelAngle(45);
	
	$bplot = new BarPlot($ydata);
	$bplot->SetWidth(0.6);
	$fcol='#440000';
	$tcol='#FF9090';
	
	$bplot->SetFillGradient($fcol,$tcol,GRAD_LEFT_REFLECTION);
	
	$bplot->SetWeight(0);
	
	$graph->Add($bplot);
	
	$lplot = new LinePlot($ydata2);
	$lplot->SetFillColor('skyblue@0.5');
	$lplot->SetColor('navy@0.7');
	$lplot->SetBarCenter();
	
	$lplot->mark->SetType(MARK_SQUARE);
	$lplot->mark->SetColor('blue@0.5');
	$lplot->mark->SetFillColor('lightblue');
	$lplot->mark->SetSize(6);
	
	$graph->Add($lplot);
	$graph->Stroke();
*/
/*
	//NOP
	include ("graficos/jpgraph.php");
	include ("graficos/jpgraph_bar.php");
	
	$months=$gDateLocale->GetShortMonth();
	
	srand ((double) microtime() * 1000000);
	for( $i=0; $i<25; ++$i) {
		$databary[]=rand(1,50);
		$databarx[]=$months[$i%12];
	}
		
	$graph = new Graph(300,200,'auto');
	$graph->SetShadow();
	
	$graph->SetScale("textlin");
	
	$graph->xaxis->SetFont(FF_FONT1,FS_NORMAL);
	$graph->xaxis->SetTickLabels($databarx);
	$graph->xaxis->SetTextLabelInterval(3);
	
	$graph->title->Set("Displaying only every third label");
	
	$graph->title->SetFont(FF_FONT1,FS_BOLD);
	
	$b1 = new BarPlot($databary);
	$b1->SetLegend("Temperature");
		
	$graph->Add($b1);
	
	$graph->Stroke();
*/
?>